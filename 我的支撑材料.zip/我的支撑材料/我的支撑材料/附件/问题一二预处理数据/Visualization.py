# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
import statsmodels.api as sm
from scipy import stats
import os
from io import BytesIO
from PIL import Image

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False   # 解决坐标轴负数的负号显示问题


# 确保输出目录存在
output_dir = "results"
os.makedirs(output_dir, exist_ok=True)


def load_data():
    """加载数据并返回包含所需列的DataFrame"""
    try:
        # 读取数据（优先从 results 目录读取预处理后的数据）
        df = pd.read_excel(os.path.join(output_dir, "预处理后数据.xlsx"))
        print("数据加载成功，原始数据 shape:", df.shape)

        # 检查是否包含必要的列
        required_cols = ["孕周数值", "孕妇BMI", "Y染色体浓度"]
        df.columns = [col.strip() for col in df.columns]  # 处理列名空格/大小写
        missing_cols = [col for col in required_cols if col not in df.columns]

        if missing_cols:
            raise ValueError(f"数据缺少必要列: {missing_cols}，需包含{required_cols}")

        return df[required_cols].copy()

    except FileNotFoundError:
        print("未找到数据文件，使用示例数据进行分析...")
        # 生成示例数据
        data = {
            "孕周数值": [11.86, 15.86, 20.14, 22.86, 13.8, 16.71, 25.0],
            "孕妇BMI": [28.125, 28.5156, 28.5156, 28.9062, 33.3318, 34.2327, 29.45],
            "Y染色体浓度": [0.0259, 0.0349, 0.0662, 0.0612, 0.0592, 0.0424, 0.071]
        }
        return pd.DataFrame(data)
    except Exception as e:
        print(f"数据加载出错: {e}")
        return None

def build_regression_model(df):
    """构建含交互项的多元线性回归模型"""
    # 1. 定义自变量（含交互项）和因变量
    X = df[["孕周数值", "孕妇BMI"]].copy()
    X["孕周×BMI"] = X["孕周数值"] * X["孕妇BMI"]  # 添加交互项
    X = sm.add_constant(X)  # 添加常数项（截距）
    y = df["Y染色体浓度"]

    # 2. 拟合OLS模型
    model = sm.OLS(y, X).fit()
    print("\n回归模型摘要:")
    print(model.summary())

    # 3. 保存模型结果到文件
    with open(os.path.join(output_dir, "回归模型结果.txt"), "w", encoding="utf-8") as f:
        f.write(str(model.summary()))

    return model, X, y

def visualize_regression(df, model):
    """回归结果可视化"""
    # 1. 孕周与Y染色体浓度关系（按BMI分组）
    df["BMI分组"] = pd.cut(df["孕妇BMI"], bins=3, labels=["低BMI", "中BMI", "高BMI"])
    plt.figure(figsize=(10, 6))
    sns.lmplot(x="孕周数值", y="Y染色体浓度", hue="BMI分组", data=df,
               height=6, aspect=1.5, scatter_kws={"alpha": 0.6})
    plt.title("不同BMI分组下孕周与Y染色体浓度的关系")
    plt.xlabel("孕周")
    plt.ylabel("Y染色体浓度")
    reg_bmi_path = os.path.join(output_dir, "不同BMI分组的回归关系.png")
    plt.savefig(reg_bmi_path, dpi=300)
    plt.show()

    # 2. 回归系数可视化
    coef = model.params.drop("const")
    plt.figure(figsize=(8, 6))
    coef.plot(kind="bar")
    plt.axhline(0, color="r", linestyle="--")
    plt.title("回归模型系数")
    plt.ylabel("系数值")
    for i, v in enumerate(coef):
        plt.text(i, v, f"{v:.4f}", ha="center", va="bottom")
    coef_path = os.path.join(output_dir, "回归系数条形图.png")
    plt.savefig(coef_path, dpi=300)
    plt.show()


def main():
    # 1. 加载数据
    df = load_data()
    if df is None or df.empty:
        print("没有可用数据，无法进行分析")
        return

    # 2. 构建回归模型
    model, X, y = build_regression_model(df)

    # 3. 调用可视化函数
    visualize_regression(df, model)


if __name__ == "__main__":
    main()