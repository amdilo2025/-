import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re
from sklearn.ensemble import RandomForestRegressor
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from scipy.stats import f
from scipy.stats import qmc
import warnings

warnings.filterwarnings('ignore')

# 设置中文显示，增加更多字体选项确保兼容性
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False
plt.style.use('seaborn-v0_8-talk')

# 定义输出目录（用于保存图形）
OUTPUT_DIR = "problem3_results"
os.makedirs(OUTPUT_DIR, exist_ok=True)


# -------------------------- 手动实现 MANOVA --------------------------
def manual_manova(X, groups):
    n = X.shape[0]
    k = len(np.unique(groups))
    p = X.shape[1]

    grand_mean = np.mean(X, axis=0)
    group_labels = np.unique(groups)
    group_means = []
    group_sizes = []

    for label in group_labels:
        group_data = X[groups == label]
        group_means.append(np.mean(group_data, axis=0))
        group_sizes.append(group_data.shape[0])

    sscp_between = np.zeros((p, p))
    for i in range(k):
        n_i = group_sizes[i]
        mean_diff = group_means[i] - grand_mean
        sscp_between += n_i * np.outer(mean_diff, mean_diff)

    sscp_within = np.zeros((p, p))
    for i in range(k):
        group_data = X[groups == group_labels[i]]
        mean_i = group_means[i]
        for x in group_data:
            x_diff = x - mean_i
            sscp_within += np.outer(x_diff, x_diff)

    # 增加数值稳定性处理，避免奇异矩阵
    epsilon = 1e-6
    sscp_within += np.eye(p) * epsilon
    sscp_total = sscp_within + sscp_between
    sscp_total += np.eye(p) * epsilon

    det_within = np.linalg.det(sscp_within)
    det_total = np.linalg.det(sscp_total)
    wilks_lambda = det_within / det_total if det_total != 0 else 0

    s = min(p, k - 1)
    if wilks_lambda == 0:
        f_stat = np.inf
    else:
        numerator = (1 - wilks_lambda ** (1 / s)) / (wilks_lambda ** (1 / s))
        denominator_df = k * p
        numerator_df = n - k - p + 1
        f_stat = numerator * (numerator_df / denominator_df)

    df_num = p * (k - 1)
    df_den = p * (n - k) - (p - k + 1) / 2
    p_value = 1 - f.cdf(f_stat, df_num, df_den) if f_stat != np.inf else 0.0

    return {
        'Wilks_Lambda': wilks_lambda,
        'F_statistic': f_stat,
        'p_value': p_value,
        '自由度': (df_num, df_den)
    }


# -------------------------- 1. 数据预处理 --------------------------
def preprocess_features():
    try:
        data_path = "C题数据.xlsx"
        # 增加文件存在性检查
        if not os.path.exists(data_path):
            print(f"错误：未找到数据文件 {data_path}")
            return None

        df = pd.read_excel(data_path, sheet_name='男胎检测数据')
        print(f"原始数据形状: {df.shape}，包含列: {df.columns.tolist()}")

        # 筛选男胎数据（参考文档：男胎 Y 染色体浓度非空）
        male_df = df[df['Y染色体浓度'].notna()].copy()
        print(f"男胎样本数量: {male_df.shape[0]}")

        # 特征列处理（清洗非数值）
        feature_cols = {
            '年龄': '年龄',
            '身高': '身高_cm',
            '体重': '体重_kg',
            '怀孕次数': '怀孕次数',
            '生产次数': '生产次数',
            '孕妇BMI': '原始BMI'
        }

        # 特征列转为数值
        for col in ['年龄', '怀孕次数', '生产次数']:
            male_df[col] = male_df[col].apply(lambda x: re.sub(r'[^\d.]', '', str(x)) if pd.notna(x) else x)
            male_df[col] = pd.to_numeric(male_df[col], errors='coerce')

        # 清洗特征列 NaN
        before_feature_clean = male_df.shape[0]
        male_df = male_df.dropna(subset=feature_cols.values())
        print(f"特征列非数值清洗：清洗前{before_feature_clean}条，清洗后{male_df.shape[0]}条")

        if male_df.shape[0] == 0:
            print("错误：特征列清洗后无样本")
            return None

        # BMI 交叉验证（文档公式）
        male_df['身高_m'] = male_df['身高'] / 100
        male_df['计算BMI'] = male_df['体重'] / (male_df['身高_m'] ** 2)
        bmi_diff = np.abs(male_df['原始BMI'] - male_df['计算BMI'])
        before_bmi = male_df.shape[0]
        male_df = male_df[bmi_diff <= 3]
        print(f"BMI 交叉验证：清洗前{before_bmi}条，清洗后{male_df.shape[0]}条")

        if male_df.shape[0] == 0:
            print("错误：BMI 清洗后无样本")
            return None

        # 孕周解析（支持多种格式）
        def parse_week(week_str):
            if pd.isna(week_str):
                return np.nan
            week_str = str(week_str).strip()
            pattern = r'^(\d+)\s*[Ww]\s*(\+?\s*\d+)?$'
            match = re.match(pattern, week_str)
            if match:
                weeks = int(match.group(1))
                days = int(re.sub(r'[+\s]', '', match.group(2))) if match.group(2) else 0
                return round(weeks + days / 7, 2)
            elif '周' in week_str:
                parts = week_str.split('周')
                weeks = int(parts[0].strip())
                days = int(re.sub(r'[^\d]', '', parts[1])) if len(parts) > 1 and '天' in parts[1] else 0
                return round(weeks + days / 7, 2)
            elif re.match(r'^\d+(\.\d+)?$', week_str):
                return float(week_str)
            else:
                print(f"无法解析的孕周格式：{week_str}，已转换为NaN")
                return np.nan

        male_df['孕周'] = male_df['检测孕周'].apply(parse_week)
        before_week = male_df.shape[0]
        male_df = male_df[(male_df['孕周'] >= 10) & (male_df['孕周'] <= 25)]  # 文档检测范围
        print(f"孕周清洗：清洗前{before_week}条，清洗后{male_df.shape[0]}条")

        if male_df.shape[0] == 0:
            print("错误：孕周清洗后无样本")
            return None

        # 保存预处理结果到输出目录
        output_path = os.path.join(OUTPUT_DIR, '1_预处理后数据.csv')
        male_df.to_csv(output_path, index=False)
        print("第一部分结果：预处理数据已保存")
        return male_df

    except Exception as e:
        print(f"数据预处理错误: {e}")
        return None


# -------------------------- 2. 计算个体达标比例 --------------------------
def calculate_达标比例(preprocessed_df):
    if preprocessed_df is None or preprocessed_df.empty:
        print("无有效数据用于计算达标比例")
        return None

    grouped = preprocessed_df.groupby('孕妇代码')
    达标比例数据 = pd.DataFrame()

    达标比例数据['孕妇代码'] = grouped.groups.keys()
    达标比例数据['总检测次数'] = grouped.size().values

    try:
        # 文档中 4% 为达标阈值
        达标次数 = grouped.apply(lambda x: sum(x['Y染色体浓度'] >= 4))
        达标比例数据['达标次数'] = 达标次数.values
        达标比例数据['达标比例'] = 达标比例数据['达标次数'] / 达标比例数据['总检测次数']
    except Exception as e:
        print(f"计算达标比例出错: {e}")
        return None

    特征列 = ['年龄', '身高_cm', '体重_kg', '怀孕次数', '生产次数', '原始BMI']
    for col in 特征列:
        达标比例数据[col] = grouped[col].mean().values

    # 保存到输出目录
    output_path = os.path.join(OUTPUT_DIR, '2_达标比例数据.csv')
    达标比例数据.to_csv(output_path, index=False)
    print("第二部分结果：达标比例数据已保存")
    return 达标比例数据


# -------------------------- 3. 随机森林特征重要性筛选 --------------------------
def select_features(达标数据):
    if 达标数据 is None or 达标数据.empty:
        print("无数据用于特征筛选")
        return None, None

    特征 = ['年龄', '身高_cm', '体重_kg', '怀孕次数', '生产次数', '原始BMI']
    X = 达标数据[特征]
    y = 达标数据['达标比例']

    rf = RandomForestRegressor(n_estimators=200, random_state=42)
    rf.fit(X, y)

    importance = pd.DataFrame({
        '特征': 特征,
        '重要性得分': rf.feature_importances_
    }).sort_values(by='重要性得分', ascending=False)

    plt.figure(figsize=(10, 6))
    sns.barplot(x='重要性得分', y='特征', data=importance, palette='YlOrBr')
    plt.title('各特征对 Y 染色体达标比例的重要性')
    plt.tight_layout()

    # 保存到输出目录并关闭图像
    output_path = os.path.join(OUTPUT_DIR, '3_特征重要性.png')
    plt.savefig(output_path)
    plt.show()
    plt.close()

    # 保存重要性得分
    importance_path = os.path.join(OUTPUT_DIR, '3_特征重要性得分.csv')
    importance.to_csv(importance_path, index=False)

    top3_features = importance['特征'].head(3).tolist()
    print(f"第三部分结果：前三重要特征为{top3_features}")
    return 达标数据, top3_features


# -------------------------- 4. K-Means 聚类分组 --------------------------
def cluster_groups(数据, top_features):
    if 数据 is None or 数据.empty or not top_features:
        print("无数据用于聚类")
        return None, None, None

    X = 数据[top_features]
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    inertias = []
    sil_scores = []
    k_range = range(2, 9)
    for k in k_range:
        kmeans = KMeans(n_clusters=k, n_init=10, random_state=42)
        labels = kmeans.fit_predict(X_scaled)
        inertias.append(kmeans.inertia_)
        sil_scores.append(silhouette_score(X_scaled, labels))

    # 绘制肘部法则和轮廓系数图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    ax1.plot(k_range, inertias, 'bo-', markerfacecolor='r')
    ax1.set_title('肘部法则（Inertia）')
    ax1.set_xlabel('聚类数 k')
    ax2.plot(k_range, sil_scores, 'go-', markerfacecolor='r')
    ax2.set_title('轮廓系数')
    ax2.set_xlabel('聚类数 k')
    plt.tight_layout()

    # 保存到输出目录并关闭图像
    output_path = os.path.join(OUTPUT_DIR, '4_聚类数选择.png')
    plt.savefig(output_path)
    plt.show()
    plt.close()

    # 增加聚类有效性检查
    if not sil_scores or max(sil_scores) < 0.2:
        print("警告：聚类效果不佳，轮廓系数低于 0.2，使用默认聚类数 k = 2")
        best_k = 2
    else:
        best_k = k_range[np.argmax(sil_scores)]

    kmeans = KMeans(n_clusters=best_k, n_init=10, random_state=42)
    数据['聚类标签'] = kmeans.fit_predict(X_scaled)

    # 保存聚类结果
    output_path = os.path.join(OUTPUT_DIR, '4_聚类结果数据.csv')
    数据.to_csv(output_path, index=False)
    print(f"第四部分结果：最佳聚类数 k={best_k}")
    return 数据, best_k, X_scaled


# -------------------------- 5. 多元方差分析验证 --------------------------
def validate_clusters(数据, X_scaled, best_k, top3_features):
    if 数据 is None or 数据.empty or best_k is None:
        print("无数据用于分组验证")
        return

    manova_result = manual_manova(X_scaled, 数据['聚类标签'])
    print("\n第五部分：多元方差分析结果")
    print(f"Wilks' Lambda: {manova_result['Wilks_Lambda']:.4f}（越接近 0，组间差异越显著）")
    print(f"F统计量: {manova_result['F_statistic']:.4f}")
    print(f"p值: {manova_result['p_value']:.6f}（p < 0.05 表示分组有效）")

    # 保存分析结果
    output_path = os.path.join(OUTPUT_DIR, '5_多元方差分析结果.txt')
    with open(output_path, 'w') as f:
        f.write(f"Wilks' Lambda: {manova_result['Wilks_Lambda']:.4f}\n")
        f.write(f"F统计量: {manova_result['F_statistic']:.4f}\n")
        f.write(f"p值: {manova_result['p_value']:.6f}\n")

    # 绘制聚类结果可视化，处理不同维度情况
    plt.figure(figsize=(10, 8))
    if X_scaled.shape[1] >= 2:
        sns.scatterplot(
            x=X_scaled[:, 0], y=X_scaled[:, 1],
            hue=数据['聚类标签'], palette='Set1', s=100
        )
        plt.xlabel(f'标准化特征 1: {top3_features[0]}')
        plt.ylabel(f'标准化特征 2: {top3_features[1]}')
    elif X_scaled.shape[1] == 1:
        # 单维度时使用 y = 0 的散点图
        sns.scatterplot(
            x=X_scaled[:, 0], y=[0] * len(X_scaled),
            hue=数据['聚类标签'], palette='Set1', s=100
        )
        plt.xlabel(f'标准化特征: {top3_features[0]}')
        plt.ylabel('')

    plt.title(f'K-Means 聚类结果（k={best_k}）')
    plt.savefig(os.path.join(OUTPUT_DIR, '5_聚类可视化.png'))
    plt.show()
    plt.close()
    print("第五部分结果：分组验证完成")


# -------------------------- 6. 最佳时点计算 --------------------------
def find_best_time(原始数据, 聚类数据, best_k):
    if 原始数据 is None or 原始数据.empty or 聚类数据 is None:
        print("无数据用于计算最佳时点")
        return None

    # 风险函数（文档分级：12 周内低风险，13 - 27 中风险）
    def risk(week):
        return 1 if week <= 12 else 2 if 13 <= week <= 27 else 3

    孕妇聚类 = 聚类数据[['孕妇代码', '聚类标签']]
    原始数据 = 原始数据.merge(孕妇聚类, on='孕妇代码', how='left')

    分组孕周数据 = []
    for cluster in range(best_k):
        cluster_data = 原始数据[原始数据['聚类标签'] == cluster].copy()
        if cluster_data.empty:
            continue

        # 修正 groupby 操作，确保正确计算达标比例
        week_groups = cluster_data.groupby('孕周', as_index=False)
        孕周达标 = week_groups.agg(
            达标比例=('Y染色体浓度', lambda x: (x >= 4).mean())
        ).reset_index(drop=True)

        孕周达标['聚类标签'] = cluster
        分组孕周数据.append(孕周达标)

    if not 分组孕周数据:
        print("无有效数据用于孕周达标分析")
        return None

    分组孕周数据 = pd.concat(分组孕周数据)
    回归参数 = {}
    for cluster in range(best_k):
        data = 分组孕周数据[分组孕周数据['聚类标签'] == cluster]
        if len(data) < 5:  # 确保有足够数据进行回归
            continue
        x = data['孕周']
        y = data['达标比例']
        回归参数[cluster] = np.polyfit(x, y, 2)  # 二次多项式拟合

    最佳时点结果 = []
    for cluster in 回归参数.keys():
        a, b, c = 回归参数[cluster]
        t_range = np.arange(10, 25.1, 0.1)
        # 目标函数：0.6*风险 + 0.4*(1-达标比例)，值越小越好
        目标函数值 = [0.6 * risk(t) + 0.4 * (1 - (a * t ** 2 + b * t + c)) for t in t_range]
        best_idx = np.argmin(目标函数值)
        best_t = t_range[best_idx]
        best_obj = 目标函数值[best_idx]

        最佳时点结果.append({
            '聚类组': cluster,
            '最佳时点(周)': best_t,
            '目标函数值': best_obj,
            '该时点风险': risk(best_t),
            '该时点达标比例': a * best_t ** 2 + b * best_t + c
        })

    结果_df = pd.DataFrame(最佳时点结果)
    output_path = os.path.join(OUTPUT_DIR, '6_最佳时点结果.csv')
    结果_df.to_csv(output_path, index=False)

    # 绘制最佳时点对比图
    plt.figure(figsize=(12, 6))
    sns.barplot(x='聚类组', y='最佳时点(周)', data=结果_df, palette='Blues_d')
    plt.title('各聚类组最佳 NIPT 检测时点')
    plt.ylim(10, 25)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.savefig(os.path.join(OUTPUT_DIR, '6_最佳时点对比.png'))
    plt.show()
    plt.close()

    print("第六部分结果：最佳时点计算完成")
    return 结果_df


# -------------------------- 误差分析 --------------------------
def error_analysis(聚类数据, top_features, 最佳时点, best_k):
    if 聚类数据 is None or 聚类数据.empty or 最佳时点 is None or best_k is None:
        print("无数据用于误差分析")
        return

    特征波动 = {f: 0.1 for f in top_features}
    n_features = len(top_features)

    sampler = qmc.LatinHypercube(d=n_features, seed=42)
    sample = sampler.random(n=1000)

    特征均值 = 聚类数据[top_features].mean().values
    特征范围 = np.array([特征均值[i] * 特征波动[top_features[i]] for i in range(n_features)])
    lhs_samples = qmc.scale(sample, 特征均值 - 特征范围, 特征均值 + 特征范围)

    时点变化 = {cluster: [] for cluster in 最佳时点['聚类组']}
    for i in range(1000):
        delta = lhs_samples[i] - 特征均值
        delta_ratio = np.mean(delta / 特征均值)

        for _, row in 最佳时点.iterrows():
            cluster = row['聚类组']
            base_t = row['最佳时点(周)']
            new_t = base_t * (1 + delta_ratio * 0.3)
            new_t = np.clip(new_t, 10, 25)  # 确保在有效范围内
            时点变化[cluster].append(new_t - base_t)

    sobol = {}
    for cluster in 时点变化:
        变化方差 = np.var(时点变化[cluster])
        sobol[cluster] = 变化方差 / sum(np.var(v) for v in 时点变化.values())

    # 绘制 Sobol 指数图
    plt.figure(figsize=(10, 6))
    sns.barplot(x=list(sobol.keys()), y=list(sobol.values()), palette='Reds')
    plt.title('各聚类组最佳时点对误差的敏感度（Sobol 指数）')
    plt.xlabel('聚类组')
    plt.ylabel('Sobol 指数')
    plt.savefig(os.path.join(OUTPUT_DIR, '误差分析_Sobol指数.png'))
    plt.show()
    plt.close()

    # 保存误差分析结果
    误差结果 = pd.DataFrame({
        '聚类组': list(sobol.keys()),
        'Sobol指数': list(sobol.values())
    })
    output_path = os.path.join(OUTPUT_DIR, '误差分析结果.csv')
    误差结果.to_csv(output_path, index=False)
    print("误差分析结果已保存")


# -------------------------- 主函数 --------------------------
if __name__ == "__main__":
    print("======= 问题三分析流程启动 =======")

    # 1. 数据预处理
    preprocessed_data = preprocess_features()

    # 2. 计算达标比例
    达标数据 = calculate_达标比例(preprocessed_data)

    # 3. 特征重要性筛选
    特征数据, top3_features = select_features(达标数据)
    if top3_features:
        print(f"选中的前三特征: {top3_features}")

    # 4. K-Means 聚类
    聚类结果, best_k, X_scaled = cluster_groups(特征数据, top3_features)

    # 5. 多元方差分析验证
    if 聚类结果 is not None and best_k is not None and top3_features:
        validate_clusters(聚类结果, X_scaled, best_k, top3_features)

    # 6. 最佳时点计算
    最佳时点结果 = find_best_time(preprocessed_data, 聚类结果, best_k)

    # 误差分析
    if 最佳时点结果 is not None and top3_features:
        error_analysis(聚类结果, top3_features, 最佳时点结果, best_k)

    print("======= 分析流程结束 =======")