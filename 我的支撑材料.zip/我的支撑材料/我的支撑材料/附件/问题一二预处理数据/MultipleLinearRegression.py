# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import statsmodels.api as sm
import os
import pandas as pd

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False   # 解决坐标轴负数的负号显示问题

# 确保输出目录存在
output_dir = "results"
os.makedirs(output_dir, exist_ok=True)


def load_data():
    """加载数据并返回包含所需列的DataFrame"""
    try:
        # 读取数据
        df = pd.read_excel(os.path.join(output_dir, "预处理后数据.xlsx"))
        print("数据加载成功，原始数据 shape:", df.shape)

        # 检查是否包含必要的列（根据实际数据列名调整）
        required_cols = ["孕周数值", "孕妇BMI", "Y染色体浓度"]
        # 处理列名可能的空格或大小写问题
        df.columns = [col.strip() for col in df.columns]
        missing_cols = [col for col in required_cols if col not in df.columns]

        if missing_cols:
            raise ValueError(f"数据缺少必要列: {missing_cols}，需包含{required_cols}")

        # 提取所需列并返回
        return df[required_cols].copy()

    except FileNotFoundError:
        print("未找到数据文件，使用示例数据进行分析...")
        # 示例数据
        data = {
            "孕周数值": [11.86, 15.86, 20.14, 22.86, 13.8, 16.71, 25.0],
            "孕妇BMI": [28.125, 28.5156, 28.5156, 28.9062, 33.3318, 34.2327, 29.45],
            "Y染色体浓度": [0.0259, 0.0349, 0.0662, 0.0612, 0.0592, 0.0424, 0.071]
        }
        return pd.DataFrame(data)
    except Exception as e:
        print(f"数据加载出错: {e}")
        return None

def build_regression_model(df):
    """构建多元线性回归模型（含交互项）"""
    # 1. 定义自变量和因变量
    X = df[["孕周数值", "孕妇BMI"]]
    # 添加交互项（孕周×BMI）
    X["孕周×BMI"] = X["孕周数值"] * X["孕妇BMI"]
    X = sm.add_constant(X)  # 添加常数项
    y = df["Y染色体浓度"]

    # 2. 拟合模型
    model = sm.OLS(y, X).fit()
    print("\n回归模型摘要:")
    print(model.summary())

    # 3. 保存模型结果
    with open(os.path.join(output_dir, "回归模型结果.txt"), "w", encoding="utf-8") as f:
        f.write(str(model.summary()))

    return model, X, y

def main():
    # 加载数据（关键：定义df）
    df = load_data()
    if df is None or df.empty:
        print("没有可用数据，无法进行分析")
        return

    model, X, y = build_regression_model(df)

if __name__ == "__main__":
    main()