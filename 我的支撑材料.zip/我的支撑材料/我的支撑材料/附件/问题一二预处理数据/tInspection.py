# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import re
import seaborn as sns
import statsmodels.api as sm
from statsmodels.regression.mixed_linear_model import MixedLM
from pygam import LinearGAM, s, te
from scipy import stats

# ---------------------- 全局设置 ----------------------
plt.rcParams['figure.dpi'] = 300
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False


# ---------------------- 1. 数据加载 ----------------------
try:
    df = pd.read_excel('C题数据.xlsx')
    print("数据加载成功，原始数据 shape:", df.shape)
except Exception as e:
    print(f"数据加载失败: {e}")


# ---------------------- 2. 数据预处理 ----------------------
df = df[df['Y染色体浓度'].notna()].copy()
print(f"\n筛选出男胎样本数：{len(df)}")

df = df.dropna(subset=['检测孕周', '孕妇BMI', 'Y染色体浓度']).reset_index(drop=True)
print(f"剔除缺失值后样本数：{len(df)}")

def convert_gestational_week(week_str):
    match = re.match(r'(\d+)w(?:\+(\d+))?', str(week_str))
    if not match:
        return np.nan
    weeks = int(match.group(1))
    days = int(match.group(2)) if match.group(2) else 0
    return weeks + days / 7

df['检测孕周（数值）'] = df['检测孕周'].apply(convert_gestational_week)
df = df.dropna(subset=['检测孕周（数值）']).reset_index(drop=True)
print(f"孕周格式转换后有效样本数：{len(df)}")

df = df[(df['Y染色体浓度'] >= 0) & (df['孕妇BMI'] <= 60)].reset_index(drop=True)
print(f"剔除异常值后最终样本数：{len(df)}")


# ---------------------- 3. 模型构建与显著性检验 ----------------------
y = df['Y染色体浓度']
X = df[['检测孕周（数值）', '孕妇BMI']].copy()
X['interaction'] = X['检测孕周（数值）'] * X['孕妇BMI']
X = sm.add_constant(X)  # 添加常数项（截距）

# 多元线性回归模型
model_linear = sm.OLS(y, X).fit()
print("\n===== 多元线性回归模型结果 =====")
print(model_linear.summary())


# ---------------------- 新增：高精度纵向对齐表格 ----------------------
print("\n===== 多元线性回归t检验结果（高精度对齐） =====")

# 步骤1：提取t检验统计量
variables = ["常数项", "检测孕周（数值）", "孕妇BMI", "孕周×BMI交互项"]
coefs = model_linear.params.values.round(4)
t_values = model_linear.tvalues.round(4)
p_values = model_linear.pvalues.round(6)
significances = ['***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else 'ns'
                  for p in model_linear.pvalues]

# 步骤2：定义列格式（变量左对齐占20字符，系数/统计量右对齐占12字符，p值右对齐占12字符，显著性右对齐占10字符）
header = "{:<20}{:>12}{:>12}{:>12}{:>10}".format("变量", "系数", "t统计量", "p值", "显著性")
print(header)
print("-" * (20 + 12 + 12 + 12 + 10))  # 打印分隔线

# 步骤3：逐行格式化输出
for var, coef, t_val, p_val, sig in zip(variables, coefs, t_values, p_values, significances):
    row = "{:<20}{:>12.4f}{:>12.4f}{:>12.6f}{:>10}".format(
        var, coef, t_val, p_val, sig
    )
    print(row)


# ---------------------- t检验结果解释 ----------------------
print("\n===== t检验结果解释 =====")
for var, coef, t_val, p_val, sig in zip(variables, coefs, t_values, p_values, significances):
    if sig != 'ns':
        print(f"{var}：系数为{coef}，t统计量为{t_val}，p值={p_val}，{sig}（显著）")
    else:
        print(f"{var}：系数为{coef}，t统计量为{t_val}，p值={p_val}，{sig}（不显著）")