# -*- coding: utf-8 -*-
import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from scipy.stats import f_oneway, tukey_hsd, shapiro, kruskal, levene
import seaborn as sns
try:
    import scikit_posthocs as sp
except ImportError:
    print("警告：未安装`scikit-posthocs`，非参数多重比较功能不可用。可通过 `pip install scikit-posthocs` 安装。")
    sp = None

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False
# 定义输出目录（用于保存图形）
OUTPUT_DIR = "problem2_results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ---------------------- 1. 数据加载与预处理 ----------------------
try:
    df = pd.read_excel("C题数据.xlsx")  # 替换为你的数据文件路径
    print("✅ 真实数据加载成功，形状：", df.shape)
except Exception as e:
    print(f"❌ 真实数据加载失败: {e}")
    raise

# 定义关键列名
col_y = 'Y染色体浓度' if 'Y染色体浓度' in df.columns else 'V'
col_bmi = '孕妇BMI' if '孕妇BMI' in df.columns else 'K'

# 筛选男性胎儿数据（Y染色体浓度非空）
male_df = df[df[col_y].notna()].copy()

# 孕周字符串转数值（若无需孕周可省略，此处为数据一致性保留）
def convert_week(week_str):
    if pd.isna(week_str):
        return np.nan
    s = str(week_str).strip().lower()
    try:
        if 'w' in s:
            week_part, day_part = s.split('w')
            weeks = float(week_part.strip()) if week_part.strip() else 0
            day_num = ''.join([c for c in day_part.strip().replace('+', '') if c.isdigit()])
            days = float(day_num) if day_num else 0
            return round(weeks + days / 7, 2)
        elif '周' in s:
            week_part, rest = s.split('周', 1)
            weeks = float(week_part)
            days = 0
            if '+' in rest or '天' in rest:
                day_num = ''.join([c for c in rest.replace('天', '').replace('+', '').strip() if c.isdigit()])
                days = float(day_num) if day_num else 0
            return round(weeks + days / 7, 2)
        elif s.replace('.', '', 1).isdigit():
            return float(s)
    except Exception:
        return np.nan
    return np.nan

male_df['gestational_week'] = male_df['检测孕周'].apply(convert_week)  # 假设原列名为“检测孕周”

# 剔除缺失与异常值
male_df = male_df.dropna(subset=['gestational_week', col_bmi, col_y])
male_df = male_df[(male_df[col_y] >= 0) & (male_df[col_bmi] <= 60)]
male_df = male_df.reset_index(drop=True)

# ---------------------- 2. BMI分组（按图片分组要求更新） ----------------------
# 按照图片指定的分组区间
bmi_bins = [26, 31.5, 34.5, 42]  # 分组区间：(26, 31.5]为低BMI，(31.5, 34.5]为中BMI，(34.5, 42]为高BMI
male_df['bmi_group'] = pd.cut(
    male_df[col_bmi],
    bins=bmi_bins,
    labels=['低BMI', '中BMI', '高BMI'],
    include_lowest=False  # 不包含左端点
)

# 检查并移除分组后的空值（处理超出指定区间的数据）
before = len(male_df)
male_df = male_df.dropna(subset=['bmi_group'])
after = len(male_df)
if before > after:
    print(f"⚠️ 移除了 {before - after} 条超出指定BMI分组区间的数据")

# 检查分组情况
print("\nBMI分组统计：")
group_counts = male_df['bmi_group'].value_counts().sort_index()
for group, count in group_counts.items():
    print(f"{group}: {count} 例")

# 提取各组Y染色体浓度数据
groups = {}
for group_name in ['低BMI', '中BMI', '高BMI']:  # 确保分组顺序正确
    if group_name in male_df['bmi_group'].unique():
        groups[group_name] = male_df[male_df['bmi_group'] == group_name][col_y]
    else:
        print(f"⚠️ 警告：{group_name}组没有数据")

# 如果存在空分组，移除空分组
groups = {k: v for k, v in groups.items() if not v.empty}

# ---------------------- 3. 方差分析前提检验 ----------------------
# 正态性检验（Shapiro-Wilk）
print("\n===== 正态性检验结果（Shapiro-Wilk） =====")
norm_tests = {}
for group_name, data in groups.items():
    norm_tests[group_name] = shapiro(data)
    print(f"{group_name}: 统计量={norm_tests[group_name].statistic:.4f}, p值={norm_tests[group_name].pvalue:.4e}")

# 方差齐性检验（Levene）
if len(groups) >= 2:
    levene_stat, levene_p = levene(*groups.values())
    print("\n===== 方差齐性检验结果（Levene） =====")
    print(f"统计量={levene_stat:.4f}, p值={levene_p:.4e}")
else:
    print("\n⚠️ 方差齐性检验未执行：有效分组不足2组")
    levene_p = np.nan  # 标记为无结果

# ---------------------- 4. 单因素方差分析/非参数检验 ----------------------
all_norm = all(test.pvalue > 0.05 for test in norm_tests.values()) if norm_tests else False  # 所有组均满足正态性
homoscedastic = levene_p > 0.05 if not np.isnan(levene_p) else False  # 方差齐性

if len(groups) >= 2:
    if all_norm and homoscedastic:
        # 满足正态性+方差齐性 → 单因素ANOVA
        f_stat, p_value = f_oneway(*groups.values())
        test_name = "单因素方差分析（ANOVA）"
    else:
        # 不满足 → Kruskal-Wallis非参数检验
        h_stat, p_value = kruskal(*groups.values())
        test_name = "Kruskal-Wallis检验（非参数）"

    print(f"\n===== {test_name}结果 =====")
    if test_name == "单因素方差分析（ANOVA）":
        print(f"F统计量: {f_stat:.4f}")
    else:
        print(f"H统计量: {h_stat:.4f}")
    print(f"p值: {p_value:.4e}")
else:
    print("\n⚠️ 无法进行组间差异检验：有效分组不足2组")
    test_name = None
    p_value = np.nan

# ---------------------- 5. 多重比较 ----------------------
if test_name == "单因素方差分析（ANOVA）" and p_value < 0.05:
    # Tukey HSD多重比较（检验组间两两差异）
    try:
        tukey_result = tukey_hsd(male_df[col_y], male_df['bmi_group'])
        print("\n===== Tukey HSD多重比较结果 =====")
        print(tukey_result)
    except Exception as e:
        print(f"Tukey HSD执行错误: {e}")
elif sp is not None and test_name == "Kruskal-Wallis检验（非参数）" and p_value < 0.05:
    # 非参数多重比较（Dunn检验，带Bonferroni校正）
    try:
        # 确保分组没有空值且标签正确
        valid_groups = male_df['bmi_group'].dropna().unique()
        if len(valid_groups) >= 2:
            dunn_result = sp.posthoc_dunn(
                male_df,
                val_col=col_y,
                group_col='bmi_group',
                p_adjust='bonferroni'
            )
            print("\n===== Dunn多重比较结果（非参数，Bonferroni校正） =====")
            print(dunn_result)
        else:
            print("\n⚠️ 多重比较未执行：有效分组不足2组")
    except Exception as e:
        print(f"Dunn检验执行错误: {e}")
else:
    print("\n⚠️ 多重比较未执行：检验不显著、分组不足或缺少`scikit-posthocs`库。")

# ---------------------- 6. 可视化分组差异（并保存图形） ----------------------
# 箱线图
plt.figure(figsize=(10, 6))
sns.boxplot(x='bmi_group', y=col_y, data=male_df, order=['低BMI', '中BMI', '高BMI'])  # 确保顺序正确
plt.title('不同BMI分组的Y染色体浓度分布（箱线图）')
plt.xlabel('BMI分组')
plt.ylabel('Y染色体浓度')
plt.grid(True, alpha=0.3)
plt.savefig(os.path.join(OUTPUT_DIR, 'bmi_y_boxplot.png'), dpi=300, bbox_inches='tight')
plt.show()

# 小提琴图（补充分布形态展示）
plt.figure(figsize=(10, 6))
sns.violinplot(x='bmi_group', y=col_y, data=male_df, order=['低BMI', '中BMI', '高BMI'])  # 确保顺序正确
plt.title('不同BMI分组的Y染色体浓度分布（小提琴图）')
plt.xlabel('BMI分组')
plt.ylabel('Y染色体浓度')
plt.grid(True, alpha=0.3)
plt.savefig(os.path.join(OUTPUT_DIR, 'bmi_y_violinplot.png'), dpi=300, bbox_inches='tight')
plt.show()

# 各组均值条形图（新增）
plt.figure(figsize=(10, 6))
sns.barplot(x='bmi_group', y=col_y, data=male_df, order=['低BMI', '中BMI', '高BMI'], errorbar='se')
plt.title('不同BMI分组的Y染色体浓度均值（带标准误）')
plt.xlabel('BMI分组')
plt.ylabel('Y染色体浓度均值')
plt.grid(True, alpha=0.3, axis='y')
plt.savefig(os.path.join(OUTPUT_DIR, 'bmi_y_mean_bar.png'), dpi=300, bbox_inches='tight')
plt.show()
