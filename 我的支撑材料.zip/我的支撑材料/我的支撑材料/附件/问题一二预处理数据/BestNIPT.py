# -*- coding: utf-8 -*-
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import norm

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False
OUTPUT_DIR = "NIPT_optimal_time_results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ---------------------- 1. 数据加载与预处理 ----------------------
try:
    df = pd.read_excel("C题数据.xlsx")
    print("✅ 数据加载成功，原始数据形状：", df.shape)
except Exception as e:
    print(f"❌ 数据加载失败: {e}")
    raise

# 定义关键列名（手动确认Excel中的实际列名，避免自动匹配错误）
col_y = "Y染色体浓度"  # 直接指定实际列名
col_bmi = "孕妇BMI"   # 直接指定实际列名
col_week = "检测孕周"  # 直接指定实际列名

# 筛选男胎数据（Y染色体浓度非空）
male_df = df[df[col_y].notna()].copy()
print(f"筛选Y非空后的数据量：{len(male_df)} 行")

# 孕周转换：将“周+天”格式转为小数周（如12周3天→12.43周）
def convert_week(week_str):
    if pd.isna(week_str):
        return np.nan
    s = str(week_str).strip().lower()
    try:
        if '周' in s:
            parts = s.split('周')
            week_part = parts[0].strip()
            weeks = float(week_part) if week_part else 0
            days = 0
            if len(parts) > 1 and parts[1].strip():
                rest = parts[1].strip()
                day_num = ''.join([c for c in rest.replace('天', '').replace('+', '').strip() if c.isdigit()])
                days = float(day_num) if day_num else 0
            return round(weeks + days / 7, 2)
        elif 'w' in s:
            parts = s.split('w')
            week_part = parts[0].strip()
            weeks = float(week_part) if week_part else 0
            days = 0
            if len(parts) > 1 and parts[1].strip():
                day_num = ''.join([c for c in parts[1].strip().replace('+', '') if c.isdigit()])
                days = float(day_num) if day_num else 0
            return round(weeks + days / 7, 2)
        elif s.replace('.', '', 1).isdigit():
            return float(s)
    except Exception as e:
        print(f"孕周转换出错，输入：{week_str}，错误：{e}")
        return np.nan
    return np.nan

male_df['gestational_week'] = male_df[col_week].apply(convert_week)
print(f"孕周转换后，gestational_week非空数量：{male_df['gestational_week'].notna().sum()}")

# 数据清洗：剔除关键列缺失值，限制合理范围
male_df = male_df.dropna(subset=['gestational_week', col_bmi, col_y])
print(f"剔除缺失值后的数据量：{len(male_df)} 行")
male_df = male_df[(male_df[col_y] >= 0) & (male_df[col_bmi] <= 60)]  # Y浓度非负 + BMI≤60
male_df = male_df.reset_index(drop=True)
print(f"最终清洗后数据量：{len(male_df)} 行")

# 打印数据统计信息，调试用
print("\n数据统计摘要：")
print(male_df.describe())
print("\n数据列信息：")
print(male_df.info())

print(f"孕周范围: {male_df['gestational_week'].min():.2f} - {male_df['gestational_week'].max():.2f}")
print(f"BMI范围: {male_df[col_bmi].min():.2f} - {male_df[col_bmi].max():.2f}")
print(f"Y浓度范围: {male_df[col_y].min():.2f} - {male_df[col_y].max():.2f}")

# ---------------------- 2. BMI分组（调整为更合理的区间，适配数据范围） ----------------------
# 调整分组区间，根据数据实际BMI范围设置（例如数据BMI最小20.7，所以低BMI从20开始）
bmi_bins = [26, 31.5, 34.5, 42]
bmi_labels = ['低BMI', '中BMI', '高BMI']

male_df['bmi_group'] = pd.cut(
    male_df[col_bmi],
    bins=bmi_bins,
    labels=bmi_labels,
    include_lowest=True  # 包含左端点
)

# 检查分组数据量
print("\nBMI分组统计：")
group_counts = male_df['bmi_group'].value_counts().sort_index()
for group, count in group_counts.items():
    print(f"{group}: {count} 例")

# 提取有效分组（排除空分组）
valid_groups = {}
for group_name in bmi_labels:
    group_data = male_df[male_df['bmi_group'] == group_name]
    if not group_data.empty:
        valid_groups[group_name] = group_data
        print(f"✅ {group_name}组有效，数据量：{len(group_data)}")
    else:
        print(f"⚠️ 警告：{group_name}组没有数据，将跳过该组分析")


# ---------------------- 3. 风险函数R(t)定义 ----------------------
def calculate_risk(t, y_concentration):
    """
    计算风险值R(t)：
    - 早期（10-12周）：基础风险0.2，未达标（<4%）则风险翻倍
    - 中期（13-25周）：基础风险1.0，未达标则风险翻倍
    - 超出范围（<10或>25周）：基础风险3.0
    """
    if 10 <= t <= 12:
        base_risk = 0.2
    elif 13 <= t <= 25:
        base_risk = 1.0
    else:
        base_risk = 3.0

    # Y染色体浓度<4%时，检测不可靠，风险翻倍
    if y_concentration < 4.0:
        return base_risk * 2
    return base_risk


# ---------------------- 4. 遍历10-25周计算每组最佳时点 ----------------------
optimal_times = {}
risk_results = {}

for group_name, group_data in valid_groups.items():
    # 遍历10-25周（步长0.1周，提高精度）
    t_range = np.arange(10, 25.1, 0.1)
    avg_concentrations = []
    risks = []

    for t in t_range:
        # 筛选当前孕周±0.5周内的数据
        window_mask = (group_data['gestational_week'] >= t - 0.5) & (group_data['gestational_week'] <= t + 0.5)
        window_data = group_data[window_mask]

        # 计算平均Y浓度（若无数据，设为0并标记风险）
        avg_conc = window_data[col_y].mean() if not window_data.empty else 0
        avg_concentrations.append(avg_conc)

        # 计算风险
        risk = calculate_risk(t, avg_conc)
        risks.append(risk)

    # 找到风险最小的时点（若多个最小值，取最早时点）
    min_risk = np.min(risks)
    min_risk_indices = np.where(risks == min_risk)[0]
    if len(min_risk_indices) > 0:
        optimal_t = t_range[min_risk_indices[0]]  # 取第一个最小风险的时点
        optimal_risk = min_risk

        optimal_times[group_name] = (optimal_t, optimal_risk)
        risk_results[group_name] = (t_range, risks, avg_concentrations)

        print(f"分组 {group_name}：最佳时点={optimal_t:.1f}周，最小风险={optimal_risk:.2f}")
    else:
        print(f"⚠️ {group_name}组无有效风险计算结果")


# ---------------------- 5. 误差分析（模拟检测误差影响） ----------------------
def simulate_error_impact(group_name, base_t, base_conc, n_sim=1000):
    """模拟误差：
    - 孕周误差：±1周（均匀分布）
    - 浓度误差：±0.5%（正态分布）
    """
    t_errors = np.random.uniform(-1, 1, n_sim)  # 孕周误差
    conc_errors = np.random.normal(0, 0.5, n_sim)  # 浓度误差

    simulated_risks = []
    for te, ce in zip(t_errors, conc_errors):
        t_sim = base_t + te
        conc_sim = max(0, base_conc + ce)  # 浓度非负
        # 限制孕周在10-25周内
        t_sim = np.clip(t_sim, 10, 25)
        simulated_risks.append(calculate_risk(t_sim, conc_sim))

    # 计算误差后的风险统计量
    risk_mean = np.mean(simulated_risks)
    risk_std = np.std(simulated_risks)
    return risk_mean, risk_std


# 对有效分组进行误差模拟
error_analysis = {}
for group_name in optimal_times:
    opt_t, opt_risk = optimal_times[group_name]
    # 获取最佳时点对应的平均浓度
    t_range, risks, concs = risk_results[group_name]
    opt_conc = concs[np.argmin(risks)]

    # 模拟误差影响
    mean_risk, std_risk = simulate_error_impact(group_name, opt_t, opt_conc)
    error_analysis[group_name] = {
        '最佳时点': opt_t,
        '基础风险': opt_risk,
        '误差后平均风险': mean_risk,
        '风险标准差': std_risk
    }

# ---------------------- 6. 可视化结果 ----------------------
# 1. 风险随孕周变化曲线 + 最佳时点标记
if risk_results:
    plt.figure(figsize=(12, 8))
    for group_name, (t_range, risks, _) in risk_results.items():
        plt.plot(t_range, risks, label=f'BMI分组 {group_name}', linewidth=2)
        # 标记最佳时点
        opt_t, opt_risk = optimal_times[group_name]
        plt.scatter(opt_t, opt_risk, s=100, marker='*', color='red')

    plt.axvline(x=12, color='gray', linestyle='--', label='早期/中期分界（12周）')
    plt.xlabel('孕周（10-25周）')
    plt.ylabel('风险值 R(t)')
    plt.title('不同BMI分组的风险随孕周变化（*为最佳时点）')
    plt.legend()
    plt.grid(alpha=0.3)
    plt.savefig(os.path.join(OUTPUT_DIR, '风险曲线与最佳时点.png'), dpi=300)
    plt.show()
else:
    print("⚠️ 无有效分组绘制风险曲线")

# 2. 误差分析结果表
if error_analysis:
    error_df = pd.DataFrame(error_analysis).T
    print("\n===== 误差分析结果 =====")
    print(error_df)
    error_df.to_excel(os.path.join(OUTPUT_DIR, '误差分析结果.xlsx'))
else:
    print("⚠️ 无有效分组进行误差分析")

# 3. 误差前后风险对比条形图
if error_analysis:
    plt.figure(figsize=(10, 6))
    error_df[['基础风险', '误差后平均风险']].plot(kind='bar')
    plt.ylabel('风险值')
    plt.title('误差前后的风险对比')
    plt.grid(alpha=0.3, axis='y')
    plt.savefig(os.path.join(OUTPUT_DIR, '误差前后风险对比.png'), dpi=300)
    plt.show()
else:
    print("⚠️ 无有效分组绘制误差对比图")