import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm
from scipy.stats import shapiro
import os

# ------------------------------
# 一、全局设置（解决中文显示问题）
# ------------------------------
plt.rcParams['font.sans-serif'] = ['SimHei']  # 解决中文乱码
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
sns.set_theme(style='whitegrid')  # 使用Seaborn主题

# 尝试自动选择可用的中文字体，避免中文字符缺失警告
try:
    import matplotlib.font_manager as fm
    candidate_fonts = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'WenQuanYi Micro Hei', 'Heiti TC']
    available = {f.name for f in fm.fontManager.ttflist}
    chosen = None
    for name in candidate_fonts:
        if name in available:
            chosen = name
            break
    if chosen:
        plt.rcParams['font.family'] = 'sans-serif'
        plt.rcParams['font.sans-serif'] = [chosen]
except Exception:
    pass


def preprocess_week(week_str):
    """将孕周字符串转换为浮点数（支持 11w+6, 15w6, 20w, 10周+3天 等）。"""
    if pd.isna(week_str):
        return np.nan
    s = str(week_str).strip().lower()
    try:
        if 'w' in s:
            week_part = s.split('w')[0].strip()
            day_part = s.split('w')[1].strip().replace('+', '').strip()
            weeks = float(week_part) if week_part else 0
            day_num = ''.join([c for c in day_part if c.isdigit()])
            days = float(day_num) if day_num else 0
            return round(weeks + days / 7, 2)
        if '周' in s:
            weeks = s.split('周')[0]
            rest = s.split('周')[1]
            days = 0
            if '+' in rest or '天' in rest:
                rest = rest.replace('天', '').replace('+', '').strip()
                day_num = ''.join([c for c in rest if c.isdigit()])
                days = float(day_num) if day_num else 0
            return round(float(weeks) + days / 7, 2)
        if s.replace('.', '', 1).isdigit():
            return float(s)
    except Exception:
        return np.nan
    return np.nan


def get_first_existing_column(df: pd.DataFrame, candidates):
    for name in candidates:
        if name in df.columns:
            return name
    return None


def load_and_preprocess_data(file_path: str) -> pd.DataFrame:
    """加载数据并完成预处理，兼容不同表头命名。"""
    df = pd.read_excel(file_path)
    df.columns = [c.strip() for c in df.columns]

    # 兼容列名（优先中文名，退化到字母列）
    col_y = get_first_existing_column(df, ['Y染色体浓度', 'V'])
    col_week = get_first_existing_column(df, ['检测孕周', 'J'])
    col_bmi = get_first_existing_column(df, ['孕妇BMI', 'K'])
    if not all([col_y, col_week, col_bmi]):
        raise ValueError(f"表头缺失，需包含 'Y染色体浓度/ V'、'检测孕周/ J'、'孕妇BMI/ K'，当前列: {df.columns.tolist()}")

    # 标准化列名
    df = df.rename(columns={col_y: 'V', col_week: '孕周_raw', col_bmi: 'K'})

    # 孕周转换
    df['孕周'] = df['孕周_raw'].apply(preprocess_week)

    # 保留关键变量非缺失
    df = df.dropna(subset=['V', 'K', '孕周']).copy()

    # 合理范围过滤
    df = df[(df['孕周'] >= 10) & (df['孕周'] <= 25)]
    df = df[(df['K'] >= 15) & (df['K'] <= 45)]

    # 生成分段变量与交互项
    df['G_12'] = np.where(df['孕周'] <= 12, df['孕周'], 12)
    df['B_28'] = np.where(df['K'] <= 28, df['K'], 28)
    df['G_B'] = df['孕周'] * df['K']

    return df


# 默认数据文件为同目录下的 C题数据.xlsx
default_path = os.path.join(os.path.dirname(__file__), 'C题数据.xlsx')
data = load_and_preprocess_data(default_path)


# ------------------------------
# 三、探索性分析（结合图片2）
# ------------------------------
def exploratory_analysis(df):
    """绘制散点图矩阵，观察变量间关系"""
    g = sns.pairplot(
        data=df[['V', '孕周', 'K']],
        diag_kind='kde',
        plot_kws={'alpha': 0.6, 's': 25},
        diag_kws={'fill': True, 'alpha': 0.3}
    )
    g.fig.suptitle("Y染色体浓度、孕周、BMI散点图矩阵", y=1.02, fontsize=14)
    g.fig.savefig('问题1_散点图矩阵.png', dpi=150, bbox_inches='tight')
    plt.close(g.fig)


# 执行探索性分析
exploratory_analysis(data)


# ------------------------------
# 四、分段多项式模型构建（结合图片1、3）
# ------------------------------
def fit_segmented_polynomial_model(df):
    """拟合分段多项式模型。"""
    formula_local = (
        'V ~ '
        '孕周 + np.square(孕周) + G_12 + np.square(G_12) + '
        'K + np.square(K) + B_28 + np.square(B_28) + '
        'G_B'
    )
    model_local = ols(formula_local, data=df).fit()
    return model_local


# 拟合模型
model = fit_segmented_polynomial_model(data)


# ------------------------------
# 五、显著性检验（结合图片3的R²=0.04）
# ------------------------------
def model_significance_test(model):
    """输出模型整体显著性、系数显著性及残差诊断"""
    # 整体显著性
    f_stat = model.fvalue
    p_value_f = model.f_pvalue

    # 系数显著性
    params = model.params.round(4)
    p_values = model.pvalues.round(4)
    conf_int = model.conf_int(alpha=0.05).round(4)

    # 残差诊断
    residuals = model.resid
    shapiro_test = shapiro(residuals)
    dw_test = sm.stats.durbin_watson(residuals)

    # 输出
    print("=" * 60)
    print("模型显著性检验结果：")
    print(f"1. 整体F检验: F={f_stat:.2f}, p={p_value_f:.4f}")
    print("2. 系数估计与显著性（t检验）：")
    print(pd.concat([params, p_values, conf_int], axis=1, keys=['系数', 'P值', '95%置信区间']))
    print(f"3. 残差正态性检验（Shapiro-Wilk）: W={shapiro_test.statistic:.4f}, p={shapiro_test.pvalue:.4f}")
    print(f"4. 残差自相关检验（Durbin-Watson）: DW={dw_test:.2f}")
    print("=" * 60)

    return {
        'params': params,
        'p_values': p_values,
        'conf_int': conf_int,
        'shapiro': shapiro_test,
        'dw': dw_test
    }


# 执行显著性检验
significance_results = model_significance_test(model)


# ------------------------------
# 六、结果可视化（结合图片1、3、4）
# ------------------------------
def visualize_results(df, model):
    """绘制拟合关系、残差图、Q-Q图。"""
    fig = plt.figure(figsize=(12, 8))
    gs = fig.add_gridspec(2, 2)

    # 子图1：拟合曲线（固定BMI为均值）
    ax1 = fig.add_subplot(gs[0, 0])
    sns.scatterplot(data=df, x='孕周', y='V', ax=ax1, alpha=0.6, label='实测值')
    xx = np.linspace(df['孕周'].min(), df['孕周'].max(), 200)
    mean_bmi = df['K'].mean()
    pred_df = pd.DataFrame({
        '孕周': xx,
        'K': mean_bmi,
        'G_12': np.where(xx <= 12, xx, 12),
        'B_28': np.where(mean_bmi <= 28, mean_bmi, 28),
        'G_B': xx * mean_bmi,
    })
    yy = model.predict(pred_df)
    ax1.plot(xx, yy, color='red', label='模型拟合')
    ax1.set_title('Y染色体浓度与孕周（固定BMI为均值）')
    ax1.legend()

    # 子图2：残差图
    ax2 = fig.add_subplot(gs[0, 1])
    sns.scatterplot(x=model.fittedvalues, y=model.resid, ax=ax2, alpha=0.6)
    ax2.axhline(y=0, color='r', linestyle='--')
    ax2.set_xlabel('拟合值')
    ax2.set_ylabel('残差')
    ax2.set_title('残差分析')

    # 子图3：Q-Q图
    ax3 = fig.add_subplot(gs[1, :])
    sm.qqplot(model.resid, line='s', ax=ax3)
    ax3.set_title('残差Q-Q图')

    plt.tight_layout()
    fig.savefig('问题1_模型结果可视化.png', dpi=150, bbox_inches='tight')
    plt.close(fig)


# 执行结果可视化
visualize_results(data, model)

# ------------------------------
# 七、结果保存
# ------------------------------
# 保存模型结果到CSV
results_summary = pd.concat([
    significance_results['params'],
    significance_results['p_values'],
    significance_results['conf_int']
], axis=1)
results_summary.columns = ['系数估计', 'P值', '下限', '上限']
results_summary.to_csv('问题1_模型参数汇总.csv', encoding='utf-8-sig')

print("所有分析完成，结果已保存至当前目录！")