# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
from pygam import LinearGAM, te, s

# 设置图片清晰度
plt.rcParams['figure.dpi'] = 300

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False

# ===================== 1. 数据加载与预处理 =====================
try:
    df = pd.read_excel("C题数据.xlsx")
    print("✅ 真实数据加载成功，形状：", df.shape)
except Exception as e:
    print(f"❌ 真实数据加载失败: {e}")
    raise

print("数据列名:", df.columns.tolist())

col_y = 'Y染色体浓度' if 'Y染色体浓度' in df.columns else 'V'
col_week = '检测孕周' if '检测孕周' in df.columns else 'J'
col_bmi = '孕妇BMI' if '孕妇BMI' in df.columns else 'K'

print(f"使用列名: Y浓度={col_y}, 孕周={col_week}, BMI={col_bmi}")

male_df = df[df[col_y].notna()].copy()

def convert_week(week_str):
    if pd.isna(week_str):
        return np.nan
    s = str(week_str).strip().lower()
    try:
        if 'w' in s:
            week_part = s.split('w')[0].strip()
            day_part = s.split('w')[1].strip().replace('+', '').strip()
            weeks = float(week_part) if week_part else 0
            day_num = ''.join([c for c in day_part if c.isdigit()])
            days = float(day_num) if day_num else 0
            return round(weeks + days / 7, 2)
        if '周' in s:
            weeks = s.split('周')[0]
            rest = s.split('周')[1]
            days = 0
            if '+' in rest or '天' in rest:
                rest = rest.replace('天', '').replace('+', '').strip()
                day_num = ''.join([c for c in rest if c.isdigit()])
                days = float(day_num) if day_num else 0
            return round(float(weeks) + days / 7, 2)
        if s.replace('.', '', 1).isdigit():
            return float(s)
    except Exception:
        return np.nan
    return np.nan


male_df['gestational_week'] = male_df[col_week].apply(convert_week)

male_df = male_df.dropna(subset=['gestational_week', col_bmi, col_y])  # 剔除关键列缺失
male_df = male_df[(male_df[col_y] >= 0) & (male_df[col_bmi] <= 60)]  # Y浓度非负 + BMI合理范围
male_df = male_df.reset_index(drop=True)

print(f"处理后数据形状: {male_df.shape}")
print(f"孕周范围: {male_df['gestational_week'].min():.2f} - {male_df['gestational_week'].max():.2f}")
print(f"BMI范围: {male_df[col_bmi].min():.2f} - {male_df[col_bmi].max():.2f}")
print(f"Y浓度范围: {male_df[col_y].min():.2f} - {male_df[col_y].max():.2f}")

X = male_df[['gestational_week', col_bmi]].values
y = male_df[col_y]

# ===================== 2. 广义加性模型（GAM）构建 =====================
gam = LinearGAM(te(0, 1, n_splines=10))

lams = np.logspace(-3, 3, 10)  # 正则化参数范围
gam.gridsearch(X, y, lam=lams)
print(f"🔍 最优正则化参数: {gam.lam}")

gam.fit(X, y)

print("\n===== GAM模型摘要 =====")
print(gam.summary())

# ===================== 3. 可视化分析 =====================
plt.figure(figsize=(16, 12))

# —— 子图1：孕周对Y浓度的非线性效应 ——
plt.subplot(2, 2, 1)
week_range = np.linspace(male_df['gestational_week'].min(),
                         male_df['gestational_week'].max(), 100)
bmi_mean = male_df[col_bmi].mean()
X_pred_week = np.column_stack([week_range, np.full_like(week_range, bmi_mean)])
y_pred_week = gam.predict(X_pred_week)

plt.plot(week_range, y_pred_week, 'b-', linewidth=2, label='GAM拟合')
plt.scatter(male_df['gestational_week'], male_df[col_y], alpha=0.3, s=10, c='red', label='原始数据')
plt.xlabel('孕周')
plt.ylabel('Y染色体浓度预测值')
plt.title('孕周对Y染色体浓度的非线性效应')
plt.legend()
plt.grid(True, alpha=0.3)

# —— 子图2：BMI对Y浓度的非线性效应 ——
plt.subplot(2, 2, 2)
bmi_range = np.linspace(male_df[col_bmi].min(),
                        male_df[col_bmi].max(), 100)
week_mean = male_df['gestational_week'].mean()
X_pred_bmi = np.column_stack([np.full_like(bmi_range, week_mean), bmi_range])
y_pred_bmi = gam.predict(X_pred_bmi)

plt.plot(bmi_range, y_pred_bmi, 'g-', linewidth=2, label='GAM拟合')
plt.scatter(male_df[col_bmi], male_df[col_y], alpha=0.3, s=10, c='red', label='原始数据')
plt.xlabel('BMI')
plt.ylabel('Y染色体浓度预测值')
plt.title('BMI对Y染色体浓度的非线性效应')
plt.legend()
plt.grid(True, alpha=0.3)

# —— 子图3：孕周×BMI的交互效应（热力图） ——
plt.subplot(2, 2, 3)
week_grid = np.linspace(male_df['gestational_week'].min(),
                        male_df['gestational_week'].max(), 50)
bmi_grid = np.linspace(male_df[col_bmi].min(),
                       male_df[col_bmi].max(), 50)
XX, YY = np.meshgrid(week_grid, bmi_grid)
ZZ = gam.predict(np.c_[XX.ravel(), YY.ravel()]).reshape(XX.shape)

# 绘制热力图
sns.heatmap(ZZ, cmap='viridis', annot=False, fmt='.3f',
            xticklabels=np.round(week_grid, 1),
            yticklabels=np.round(bmi_grid, 1),
            cbar_kws={'label': 'Y染色体浓度预测值'})
plt.xlabel('孕周')
plt.ylabel('BMI')
plt.title('孕周×BMI的交互效应（热力图）')

# —— 子图4：残差分析（判断模型拟合合理性） ——
plt.subplot(2, 2, 4)
residuals = y - gam.predict(X)
plt.scatter(gam.predict(X), residuals, alpha=0.5)
plt.axhline(y=0, color='r', linestyle='-')
plt.xlabel('模型预测值')
plt.ylabel('残差')
plt.title('残差图（若残差随机分布，说明模型无系统偏差）')

plt.tight_layout()
plt.show()

# ===================== 4. 分组分析（不同BMI下的孕周效应） =====================
bmi_bins = [18, 24, 28, 40]
male_df['bmi_group'] = pd.cut(male_df[col_bmi], bins=bmi_bins,
                              labels=['低BMI', '正常BMI', '高BMI'])

plt.figure(figsize=(12, 6))
colors = ['blue', 'green', 'orange', 'purple']
for i, (group, data) in enumerate(male_df.groupby('bmi_group')):
    if len(data) > 10:
        gam_group = LinearGAM(s(0)).fit(data['gestational_week'], data[col_y])

        week_range = np.linspace(data['gestational_week'].min(),
                                 data['gestational_week'].max(), 100)
        y_pred = gam_group.predict(week_range)

        plt.plot(week_range, y_pred, color=colors[i % len(colors)],
                 linewidth=2, label=f'{group} (n={len(data)})')

plt.scatter(male_df['gestational_week'], male_df[col_y],
            alpha=0.2, c='gray', label='原始数据')
plt.xlabel('孕周')
plt.ylabel('Y染色体浓度')
plt.title('不同BMI分组下，孕周对Y染色体浓度的影响差异')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()