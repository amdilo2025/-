# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import re
import seaborn as sns
import statsmodels.api as sm
from statsmodels.regression.mixed_linear_model import MixedLM
from pygam import LinearGAM, s, te
from scipy import stats

# 设置图片清晰度
plt.rcParams['figure.dpi'] = 300

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False


# 绘制GAM模型依赖图
def plot_partial_custom(gam, feature_idx, X, y, ax=None, title=None, xlabel=None, cmap='viridis'):
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 5))

    x_min = X[:, feature_idx].min()
    x_max = X[:, feature_idx].max()
    x_range = np.linspace(x_min, x_max, 100)

    print(f"特征 {feature_idx} 原始数据范围: {x_min:.2f} 到 {x_max:.2f}")
    print(f"x_range 范围: {x_range.min():.2f} 到 {x_range.max():.2f}")

    y_partial = []
    for x_val in x_range:
        # 创建测试数据
        X_test = np.zeros((1, X.shape[1]))
        for j in range(X.shape[1]):
            if j == feature_idx:
                X_test[0, j] = x_val
            else:
                X_test[0, j] = np.mean(X[:, j])

        y_pred = gam.predict(X_test)
        y_partial.append(y_pred[0])

    y_partial = np.array(y_partial)

    # 绘制非线性效应
    ax.plot(x_range, y_partial, color='darkblue', linewidth=2, label='GAM拟合')

    # 添加原始数据散点图作为参考
    ax.scatter(X[:, feature_idx], y, alpha=0.3, color='red', s=10, label='原始数据')

    # 调试信息
    print(f"特征 {feature_idx} 预测值范围: {y_partial.min():.4f} 到 {y_partial.max():.4f}")
    print(f"特征 {feature_idx} 数据范围: {X[:, feature_idx].min():.4f} 到 {X[:, feature_idx].max():.4f}")
    print(f"x_range 范围: {x_range.min():.4f} 到 {x_range.max():.4f}")

    # 尝试添加95%置信区间
    try:
        ci_lower = []
        ci_upper = []
        for x_val in x_range:
            X_test = np.zeros((1, X.shape[1]))
            for j in range(X.shape[1]):
                if j == feature_idx:
                    X_test[0, j] = x_val
                else:
                    X_test[0, j] = np.mean(X[:, j])

            pred = gam.prediction_intervals(X_test, width=0.95)
            ci_lower.append(pred[0, 0])
            ci_upper.append(pred[0, 1])

        ax.fill_between(x_range, ci_lower, ci_upper, color='lightblue', alpha=0.3, label='95%置信区间')
    except:
        pass

    ax.set_title(title, fontsize=12)
    ax.set_xlabel(xlabel, fontsize=10)
    ax.set_ylabel('Y染色体浓度预测值', fontsize=10)
    ax.grid(alpha=0.3)
    ax.legend()

    ax.set_xlim(x_min, x_max)

    if feature_idx == 0:  # 孕周
        ax.set_xticks(np.arange(int(x_min), int(x_max) + 1, 2))
    else:  # BMI
        ax.set_xticks(np.arange(int(x_min), int(x_max) + 1, 5))

    ax.tick_params(axis='x', rotation=0)
    ax.tick_params(axis='y', rotation=0)

    print(f"最终x轴范围: {ax.get_xlim()}")
    print(f"最终x轴刻度: {ax.get_xticks()}")

    return ax


#绘制交互项效应图
def plot_interaction_custom(gam, feature1_idx, feature2_idx, X, ax=None, title=None,
                            xlabel=None, ylabel=None, cmap='viridis'):
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 6))

    x1_range = np.linspace(X[:, feature1_idx].min(), X[:, feature1_idx].max(), 30)
    x2_range = np.linspace(X[:, feature2_idx].min(), X[:, feature2_idx].max(), 30)
    X1, X2 = np.meshgrid(x1_range, x2_range)

    Z = np.zeros_like(X1)

    for i in range(X1.shape[0]):
        for j in range(X1.shape[1]):
            # 创建测试数据
            X_test = np.zeros((1, X.shape[1]))
            for k in range(X.shape[1]):
                if k == feature1_idx:
                    X_test[0, k] = X1[i, j]
                elif k == feature2_idx:
                    X_test[0, k] = X2[i, j]
                else:
                    X_test[0, k] = np.mean(X[:, k])

            Z[i, j] = gam.predict(X_test)[0]

    # 绘制热图
    im = ax.contourf(X1, X2, Z, levels=20, cmap=cmap, alpha=0.8)
    plt.colorbar(im, ax=ax, label='预测值')

    ax.scatter(X[:, feature1_idx], X[:, feature2_idx], c='red', s=10, alpha=0.5, label='原始数据')

    ax.set_title(title, fontsize=12)
    ax.set_xlabel(xlabel, fontsize=10)
    ax.set_ylabel(ylabel, fontsize=10)
    ax.legend()

    return ax


# 1. 数据加载
try:
    df = pd.read_excel('C题数据.xlsx')
    print("数据加载成功，原始数据 shape:", df.shape)
except Exception as e:
    print(f"数据加载失败: {e}")

# 2. 数据预处理
df = df[df['Y染色体浓度'].notna()].copy()
print(f"\n筛选出男胎样本数：{len(df)}")

df = df.dropna(subset=['检测孕周', '孕妇BMI', 'Y染色体浓度']).reset_index(drop=True)
print(f"剔除缺失值后样本数：{len(df)}")

def convert_gestational_week(week_str):
    match = re.match(r'(\d+)w(?:\+(\d+))?', str(week_str))
    if not match:
        return np.nan
    weeks = int(match.group(1))
    days = int(match.group(2)) if match.group(2) else 0
    return weeks + days / 7


df['检测孕周（数值）'] = df['检测孕周'].apply(convert_gestational_week)
df = df.dropna(subset=['检测孕周（数值）']).reset_index(drop=True)
print(f"孕周格式转换后有效样本数：{len(df)}")

df = df[(df['Y染色体浓度'] >= 0) & (df['孕妇BMI'] <= 60)].reset_index(drop=True)
print(f"剔除异常值后最终样本数：{len(df)}")

# 3. 探索性数据分析
# 描述性统计
print("\n数据基本统计量：")
print(df[['检测孕周（数值）', '孕妇BMI', 'Y染色体浓度']].describe())

# 散点图矩阵：观察变量关系
plt.figure(figsize=(12, 8))
sns.pairplot(df[['检测孕周（数值）', '孕妇BMI', 'Y染色体浓度']])
plt.suptitle('变量关系散点图矩阵', y=1.02)
plt.show()

# 相关性分析（Pearson与Spearman）
corr_data = df[['检测孕周（数值）', '孕妇BMI', 'Y染色体浓度']]
corr_pearson = corr_data.corr(method='pearson')
corr_spearman = corr_data.corr(method='spearman')

print("\nPearson相关系数：")
print(corr_pearson)
print("\nSpearman相关系数：")
print(corr_spearman)

# 绘制相关性热力图
plt.figure(figsize=(10, 6))
sns.heatmap(corr_pearson, annot=True, cmap='coolwarm', vmin=-1, vmax=1)
plt.title('Pearson相关性热力图')
plt.show()

# 4. 模型构建与显著性检验
y = df['Y染色体浓度']
X = df[['检测孕周（数值）', '孕妇BMI']].copy()
X['interaction'] = X['检测孕周（数值）'] * X['孕妇BMI']
X = sm.add_constant(X)

# 4.1 多元线性回归模型
model_linear = sm.OLS(y, X).fit()
print("\n===== 多元线性回归模型结果 =====")
print(model_linear.summary())

# 4.2 混合效应线性模型（考虑重复测量）
if '孕妇代码' in df.columns:
    groups = df['孕妇代码']
    model_mixed = MixedLM(y, X, groups).fit(reml=True)
    print("\n===== 混合效应线性模型结果 =====")
    print(model_mixed.summary())

    # 混合效应模型显著性检验（似然比检验）
    model_mixed_null = MixedLM(y, sm.add_constant(X[['检测孕周（数值）', '孕妇BMI']]), groups).fit(reml=False)
    lr_test = -2 * (model_mixed_null.llf - model_mixed.llf)
    p_value = stats.chi2.sf(lr_test, df=1)
    print(f"\n混合效应模型似然比检验（交互项显著性）：χ²={lr_test:.4f}, p值={p_value:.4f}")
else:
    print("\n数据中未找到'孕妇代码'列，无法构建混合效应模型")

# 4.3 广义加性模型（GAM，捕捉非线性关系）
print("\n开始构建GAM模型...")
X_gam = df[['检测孕周（数值）', '孕妇BMI']].values
print(f"GAM输入数据形状: {X_gam.shape}")

try:
    gam = LinearGAM(s(0) + s(1) + te(0, 1)).fit(X_gam, y)
    print("GAM模型拟合成功！")
    print("\n===== 广义加性模型（GAM）结果 =====")
    print(gam.summary())

    # 使用pyGAM内置绘图功能（更可靠）
    print("\n开始绘制GAM效应图...")
    print(f"数据范围 - 孕周: {X_gam[:, 0].min():.2f} 到 {X_gam[:, 0].max():.2f}")
    print(f"数据范围 - BMI: {X_gam[:, 1].min():.2f} 到 {X_gam[:, 1].max():.2f}")
    print(f"Y染色体浓度范围: {y.min():.2f} 到 {y.max():.2f}")

    # 使用独立的图形窗口避免subplot冲突
    print("使用独立图形窗口绘制GAM效应图...")

    # 图1：孕周的平滑效应
    fig1, ax1 = plt.subplots(figsize=(6, 5))
    plot_partial_custom(gam, 0, X_gam, y, ax=ax1,
                        title='孕周对Y浓度的非线性效应',
                        xlabel='检测孕周（数值）')
    plt.tight_layout()
    plt.savefig('GAM_孕周效应.png', dpi=150, bbox_inches='tight')
    plt.show()

    # 图2：BMI的平滑效应
    fig2, ax2 = plt.subplots(figsize=(6, 5))
    plot_partial_custom(gam, 1, X_gam, y, ax=ax2,
                        title='BMI对Y浓度的非线性效应',
                        xlabel='孕妇BMI')
    plt.tight_layout()
    plt.savefig('GAM_BMI效应.png', dpi=150, bbox_inches='tight')
    plt.show()

    # 图3：交互项效应
    fig3, ax3 = plt.subplots(figsize=(6, 5))
    plot_interaction_custom(gam, 0, 1, X_gam, ax=ax3,
                            title='孕周×BMI的交互效应',
                            xlabel='检测孕周（数值）',
                            ylabel='孕妇BMI')
    plt.tight_layout()
    plt.savefig('GAM_交互效应.png', dpi=150, bbox_inches='tight')
    plt.show()

    print("GAM效应图（独立窗口）绘制完成！")

    # 方法3：简单的散点图 + 拟合曲线
    print("\n尝试简单散点图方法...")
    plt.figure(figsize=(15, 5))

    # 孕周 vs Y浓度
    plt.subplot(1, 3, 1)
    plt.scatter(X_gam[:, 0], y, alpha=0.5, s=10, color='blue', label='原始数据')

    # 添加简单的多项式拟合
    from numpy.polynomial import Polynomial

    poly = Polynomial.fit(X_gam[:, 0], y, deg=2)
    x_smooth = np.linspace(X_gam[:, 0].min(), X_gam[:, 0].max(), 100)
    y_smooth = poly(x_smooth)
    plt.plot(x_smooth, y_smooth, 'r-', linewidth=2, label='多项式拟合')

    plt.xlabel('检测孕周（数值）')
    plt.ylabel('Y染色体浓度')
    plt.title('孕周 vs Y染色体浓度')
    plt.grid(True, alpha=0.3)
    plt.legend()

    # BMI vs Y浓度
    plt.subplot(1, 3, 2)
    plt.scatter(X_gam[:, 1], y, alpha=0.5, s=10, color='green', label='原始数据')

    # 添加简单的多项式拟合
    poly2 = Polynomial.fit(X_gam[:, 1], y, deg=2)
    x_smooth2 = np.linspace(X_gam[:, 1].min(), X_gam[:, 1].max(), 100)
    y_smooth2 = poly2(x_smooth2)
    plt.plot(x_smooth2, y_smooth2, 'r-', linewidth=2, label='多项式拟合')

    plt.xlabel('孕妇BMI')
    plt.ylabel('Y染色体浓度')
    plt.title('BMI vs Y染色体浓度')
    plt.grid(True, alpha=0.3)
    plt.legend()

    # 孕周 vs BMI 散点图
    plt.subplot(1, 3, 3)
    scatter = plt.scatter(X_gam[:, 0], X_gam[:, 1], c=y, cmap='viridis', alpha=0.6, s=20)
    plt.colorbar(scatter, label='Y染色体浓度')
    plt.xlabel('检测孕周（数值）')
    plt.ylabel('孕妇BMI')
    plt.title('孕周 vs BMI (颜色表示Y浓度)')
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('GAM_简单散点图.png', dpi=150, bbox_inches='tight')
    plt.show()
    print("简单散点图绘制完成！")

except Exception as e:
    print(f"GAM模型构建或绘图失败: {e}")
    print("尝试简化GAM模型...")
    try:
        # 简化的GAM模型（只包含主效应）
        gam_simple = LinearGAM(s(0) + s(1)).fit(X_gam, y)
        print("简化GAM模型拟合成功！")

        plt.figure(figsize=(12, 4))

        plt.subplot(1, 2, 1)
        plot_partial_custom(gam_simple, 0, X_gam, y,
                            title='孕周对Y浓度的非线性效应',
                            xlabel='检测孕周（数值）')

        plt.subplot(1, 2, 2)
        plot_partial_custom(gam_simple, 1, X_gam, y,
                            title='BMI对Y浓度的非线性效应',
                            xlabel='孕妇BMI')

        plt.tight_layout()
        plt.savefig('GAM_简化效应分析图.png', dpi=150, bbox_inches='tight')
        plt.show()
        print("简化GAM效应图绘制完成！")

    except Exception as e2:
        print(f"简化GAM模型也失败: {e2}")
        print("跳过GAM分析...")


