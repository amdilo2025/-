# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import curve_fit
import statsmodels.api as sm
from statsmodels.formula.api import ols
import seaborn as sns
import matplotlib.pyplot as plt
import re

# 设置图片清晰度
plt.rcParams['figure.dpi'] = 300

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False   # 解决坐标轴负数的负号显示问题


# Step 1：数据预处理
def data_preprocessing(df):
    # 删除Y染色体浓度为空的样本（女胎数据）
    df = df.dropna(subset=['Y染色体浓度'])
    # 确保 Y 染色体浓度 为数值
    df['Y染色体浓度'] = pd.to_numeric(df['Y染色体浓度'], errors='coerce')
    df = df.dropna(subset=['Y染色体浓度'])

    # 处理检测孕周：支持 "11w+6"、"16W+1"、"12+3"、"11周+6天" 等格式
    def parse_gestational_week(x):
        if pd.isna(x):
            return np.nan
        s = str(x).strip()
        if s == '':
            return np.nan
        s = s.replace('（', '(').replace('）', ')')
        s = s.replace('周', 'w').replace('天', '').replace('W', 'w')
        s = s.replace('周+', 'w+')

        m = re.match(r"^(?P<w>\d+(?:\.\d+)?)(?:\s*[wW]?)\s*(?:\+\s*(?P<d>\d+(?:\.\d+)?))?\s*$", s)
        if m:
            weeks = float(m.group('w'))
            days = float(m.group('d')) if m.group('d') is not None else 0.0
            return weeks + days / 7.0
        return np.nan

    df['检测孕周'] = df['检测孕周'].apply(parse_gestational_week)
    # 强制转换为数值类型，错误值设为NaN
    df['检测孕周'] = pd.to_numeric(df['检测孕周'], errors='coerce')
    # 删除检测孕周为NaN的无效行
    df = df.dropna(subset=['检测孕周'])

    # 对BMI、孕周进行离群值处理；若过滤后为空，则跳过过滤
    filtered = df[(df['孕妇BMI'] <= 45) & (df['检测孕周'] <= 25)]
    if filtered.empty:
        # 使用分位数进行温和过滤作为备选；若仍为空，则不做过滤
        bmi_q_hi = df['孕妇BMI'].quantile(0.99)
        week_q_hi = df['检测孕周'].quantile(0.99)
        filtered = df[(df['孕妇BMI'] <= bmi_q_hi) & (df['检测孕周'] <= week_q_hi)]
        if filtered.empty:
            filtered = df
    df = filtered

    # 衍生变量：孕周平方项、BMI分组、BMI与孕周交互项
    df['孕周平方'] = df['检测孕周'] ** 2
    df['BMI分组'] = pd.cut(df['孕妇BMI'], bins=[20, 28, 32, 36, 40, np.inf],
                          labels=['[20,28)', '[28,32)', '[32,36)', '[36,40)', '40以上'])
    df['BMI与孕周交互项'] = df['检测孕周'] * df['孕妇BMI']

    # 若最终仍为空，则给出清晰错误
    if df.empty:
        raise ValueError('数据预处理后数据为空，请检查原始数据格式（检测孕周/BMI）或放宽过滤条件。')

    return df


# Step 2：机理建模
def ode_model_factory(t_points, bmi_points, a, b, c):
    # 使用线性插值避免通过浮点等号匹配行
    t_points_sorted_idx = np.argsort(t_points)
    t_sorted = np.array(t_points)[t_points_sorted_idx]
    bmi_sorted = np.array(bmi_points)[t_points_sorted_idx]

    def bmi_at(time_value):
        return float(np.interp(time_value, t_sorted, bmi_sorted,
                               left=bmi_sorted[0], right=bmi_sorted[-1]))

    def ode_model(t, y):
        return -a * y + b * t + c * bmi_at(t)

    return ode_model


# Step 3：数据驱动建模
def nonlinear_regression(X, alpha, beta, gamma, delta):
    J = X[:, 0]
    K = X[:, 1]
    return alpha * J ** beta * K ** gamma * np.exp(delta * J)


# 读取数据
df = pd.read_excel('C题数据.xlsx', sheet_name='男胎检测数据')

# 重命名列名，方便后续操作
df.rename(columns={'检测孕周': '检测孕周', '孕妇BMI': '孕妇BMI', 'Y染色体浓度': 'Y染色体浓度'}, inplace=True)

from numpy import isfinite

# 数据预处理
df = data_preprocessing(df)

# Step 2：机理建模求解
# 初始条件：取数值型且有限的最小值
y_series = pd.to_numeric(df['Y染色体浓度'], errors='coerce').dropna()
if y_series.empty:
    raise ValueError('无法为微分方程提供初始条件：Y染色体浓度列为空或不可用。')

y0_value = float(y_series.min())
if not np.isfinite(y0_value):
    raise ValueError('初始条件 y0 不是有限值，请检查数据。')
y0 = [y0_value]

t_min = float(df['检测孕周'].min())
t_max = float(df['检测孕周'].max())
if not (np.isfinite(t_min) and np.isfinite(t_max)):
    raise ValueError('时间范围 t_span 含有非有限值，请检查检测孕周列。')
if t_max <= t_min:
    raise ValueError('时间范围无效：最大孕周不大于最小孕周，无法积分。')

t_span = (t_min, t_max)
t_eval = np.linspace(t_span[0], t_span[1], 100)

# 构造 ODE 模型（插值 BMI）并求解
ode_fun = ode_model_factory(df['检测孕周'].values, df['孕妇BMI'].values, 0.12, 0.03, -0.005)
sol = solve_ivp(ode_fun, t_span, y0, t_eval=t_eval)

# 计算RMSE
y_true = df['Y染色体浓度'].values
y_pred_ode = np.interp(df['检测孕周'], sol.t, sol.y[0])
rmse_ode = np.sqrt(np.mean((y_pred_ode - y_true) ** 2))

# Step 3：数据驱动建模参数估计
X = df[['检测孕周', '孕妇BMI']].values
y = df['Y染色体浓度'].values
popt, _ = curve_fit(nonlinear_regression, X, y, p0=[0.04, 1.2, -0.3, 0.01])
y_pred_nonlinear = nonlinear_regression(X, *popt)

# Step 4：显著性检验
# 构建模型
model = ols('Y染色体浓度 ~ 检测孕周 + 孕妇BMI', data=df).fit()
anova_table = sm.stats.anova_lm(model, typ=2)

# Step 5：模型验证
# 划分训练集和测试集
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 重新拟合非线性回归模型（在训练集上）
popt_train, _ = curve_fit(nonlinear_regression, X_train, y_train, p0=[0.04, 1.2, -0.3, 0.01])
y_pred_test = nonlinear_regression(X_test, *popt_train)

# 计算MSE和R^2
from sklearn.metrics import mean_squared_error, r2_score

mse = mean_squared_error(y_test, y_pred_test)
r2 = r2_score(y_test, y_pred_test)

# 结果展示
# (1) 数据分布可视化
g = sns.pairplot(df[['Y染色体浓度', '检测孕周', '孕妇BMI']], diag_kind='kde')
g.fig.suptitle('散点图矩阵')
plt.savefig('散点图矩阵.png')
plt.show()

# (2) 模型拟合结果
# 微分方程拟合
plt.figure(figsize=(10, 6))
plt.scatter(df['检测孕周'], df['Y染色体浓度'], label='实测值')
plt.plot(sol.t, sol.y[0], color='red', label=f'微分方程拟合，RMSE={rmse_ode:.2%}')
plt.xlabel('孕周')
plt.ylabel('Y染色体浓度')
plt.title('微分方程拟合结果')
plt.legend()
plt.savefig('微分方程拟合结果.png')
plt.show()

# 非线性回归拟合
plt.figure(figsize=(10, 6))
plt.scatter(df['检测孕周'], df['Y染色体浓度'], label='实测值')
plt.scatter(df['检测孕周'], y_pred_nonlinear, color='green', label=f'非线性回归拟合，R^2={model.rsquared:.2f}')
plt.xlabel('孕周')
plt.ylabel('Y染色体浓度')
plt.title('非线性回归拟合结果')
plt.legend()
plt.savefig('非线性回归拟合结果.png')
plt.show()

# (3) 显著性分析
print(anova_table)

# 结果分析
print(f'微分方程拟合参数：a=0.12, b=0.03, c=-0.005；RMSE={rmse_ode:.2%}')
print(f'非线性回归拟合最优模型：Y = {popt[0]:.2f}J^{popt[1]:.1f}K^{popt[2]:.1f}e^{popt[3]:.2f}；R^2={model.rsquared:.2f}')
print(f'交叉验证结果：MSE={mse:.4f}, R^2={r2:.2f}')
print('模型局限性：未考虑多次检测的时空异质性（如不同孕周检测结果差异）；未纳入IVF妊娠方式等潜在混杂因素。')
print('改进方向：在后续分析中引入分组优化，区分不同BMI群体的动态变化规律。')

# 保存结果到csv文件
result_df = pd.DataFrame({
    '分析内容': ['微分方程拟合参数', '微分方程RMSE', '非线性回归模型', '非线性回归R^2', '交叉验证MSE', '交叉验证R^2'],
    '结果': [f'a=0.12, b=0.03, c=-0.005', f'{rmse_ode:.2%}',
             f'Y = {popt[0]:.2f}J^{popt[1]:.1f}K^{popt[2]:.1f}e^{popt[3]:.2f}', f'{model.rsquared:.2f}',
             f'{mse:.4f}', f'{r2:.2f}']
})
result_df.to_csv('问题一结果.csv', index=False)