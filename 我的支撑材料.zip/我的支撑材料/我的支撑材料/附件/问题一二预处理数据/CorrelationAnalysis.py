# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import os

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False   # 解决坐标轴负数的负号显示问题
# 确保输出目录存在
output_dir = "results"
os.makedirs(output_dir, exist_ok=True)


def load_data():
    try:
        df = pd.read_excel(os.path.join(output_dir, "预处理后数据.xlsx"))
        print("数据加载成功，原始数据 shape:", df.shape)

        required_cols = ["孕周数值", "孕妇BMI", "Y染色体浓度"]

        df.columns = [col.strip() for col in df.columns]
        missing_cols = [col for col in required_cols if col not in df.columns]

        if missing_cols:
            raise ValueError(f"数据缺少必要列: {missing_cols}，需包含{required_cols}")

        return df[required_cols].copy()

    except FileNotFoundError:
        print("未找到数据文件，使用示例数据进行分析...")
        return None
    except Exception as e:
        print(f"数据加载出错: {e}")
        return None


def correlation_analysis(df):
    """相关性分析"""
    corr_matrix = df[["孕周数值", "孕妇BMI", "Y染色体浓度"]].corr()
    print("\n相关性矩阵:")
    print(corr_matrix.round(3))

    plt.figure(figsize=(12, 10))
    g = sns.pairplot(df[["孕周数值", "孕妇BMI", "Y染色体浓度"]],
                    diag_kind="kde",
                    plot_kws={"alpha": 0.2, "s": 10, "edgecolor": "k"})
    g.fig.suptitle("变量散点图矩阵", y=1.02)
    pairplot_path = os.path.join(output_dir, "散点图矩阵.png")
    plt.savefig(pairplot_path, dpi=300)
    plt.show()

    return corr_matrix

def main():
    df = load_data()
    if df is None or df.empty:
        print("没有可用数据，无法进行分析")
        return

    corr_matrix = correlation_analysis(df)


if __name__ == "__main__":
    main()