# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.stats.diagnostic import lilliefors
from scipy.optimize import minimize
from scipy.stats import beta
import warnings
import re

warnings.filterwarnings("ignore")

# ---------------------- 全局设置 ----------------------
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.style.use('seaborn-v0_8-paper')


# ---------------------- 1. 数据加载与清洗 ----------------------
def load_clean_data(file_path):
    df = pd.read_excel(file_path)

    # 处理孕周格式（兼容多种格式）
    def convert_week(x):
        if not isinstance(x, str):
            return float(x) if pd.notna(x) else np.nan

        # 提取所有数字
        nums = re.findall(r'\d+\.?\d*', x)
        if len(nums) == 1:
            return float(nums[0])
        elif len(nums) >= 2:
            weeks = float(nums[0])
            days = float(nums[1])
            return weeks + days / 7
        else:
            return np.nan

    df['孕周'] = df['检测孕周'].apply(convert_week)

    # 处理BMI异常值
    df = df[(df['孕妇BMI'] >= 15) & (df['孕妇BMI'] <= 45)]

    # 处理Y染色体浓度
    df['Y染色体浓度'] = df['Y染色体浓度'].clip(0.001, 0.999)

    # 生成分段变量
    df['孕周_低'] = np.where(df['孕周'] <= 14, df['孕周'], 14)
    df['孕周_高'] = np.where(df['孕周'] > 14, df['孕周'] - 14, 0)

    # 移除孕周缺失的行
    df = df.dropna(subset=['孕周'])

    return df


# 加载数据
df = load_clean_data('C题数据.xlsx')

# ---------------------- 2. 特征工程 ----------------------
df['孕周_BMI'] = df['孕周'] * df['孕妇BMI']
df['孕周_sq'] = df['孕周'] ** 2
df['BMI_sq'] = df['孕妇BMI'] ** 2

# 准备特征
X = df[['孕周', '孕妇BMI', '孕周_BMI', '孕周_sq', 'BMI_sq']]
X = sm.add_constant(X)
y = df['Y染色体浓度']


# ---------------------- 3. 手动实现Beta回归 ----------------------
class ManualBetaRegression:
    def __init__(self):
        self.coef_ = None
        self.alpha_ = None
        self.log_likelihood_ = None

    def fit(self, X, y):
        n_features = X.shape[1]

        def neg_log_likelihood(params):
            beta_coef = params[:n_features]
            alpha = np.exp(params[-1])
            mu = 1 / (1 + np.exp(-X @ beta_coef))
            ll = beta.logpdf(y, mu * alpha, (1 - mu) * alpha)
            return -np.sum(ll)

        init_params = np.zeros(n_features + 1)
        result = minimize(neg_log_likelihood, init_params, method='L-BFGS-B')

        self.coef_ = result.x[:n_features]
        self.alpha_ = np.exp(result.x[-1])
        self.log_likelihood_ = -result.fun

    def predict(self, X):
        if self.coef_ is None:
            raise ValueError("模型未拟合，请先调用fit方法")
        return 1 / (1 + np.exp(-X @ self.coef_))


# ---------------------- 4. 模型构建 ----------------------
def build_models(df, X, y):
    # 模型1：普通线性回归
    model_ols = smf.ols(
        'Y染色体浓度 ~ 孕周 + 孕妇BMI + 孕周_BMI + 孕周_sq + BMI_sq',
        data=df
    ).fit()

    # 模型2：手动Beta回归
    model_beta = ManualBetaRegression()
    model_beta.fit(X, y)

    # 模型3：混合效应模型
    model_mixed = smf.mixedlm(
        'Y染色体浓度 ~ 孕周 + 孕妇BMI + 孕周_BMI + 孕周_sq + BMI_sq',
        data=df,
        groups='孕妇代码',
        re_formula="~1"
    ).fit(reml=True)

    return model_ols, model_beta, model_mixed


model_ols, model_beta, model_mixed = build_models(df, X, y)


# ---------------------- 5. 模型诊断与可视化 ----------------------
def model_diagnostics(model_ols, model_beta, model_mixed, df, X):
    fig = plt.figure(figsize=(18, 15))

    # OLS诊断
    ax1 = fig.add_subplot(2, 2, 1)
    sm.graphics.plot_fit(model_ols, 1, ax=ax1)
    ax1.set_title('OLS拟合诊断')

    # Beta回归诊断
    ax2 = fig.add_subplot(2, 2, 2)
    y_pred_beta = model_beta.predict(X)
    ax2.scatter(y, y_pred_beta, alpha=0.5)
    ax2.plot([y.min(), y.max()], [y.min(), y.max()], 'r--')
    ax2.set_xlabel('实际值')
    ax2.set_ylabel('预测值')
    ax2.set_title('Beta回归预测值 vs 实际值')

    # 混合效应残差箱线图
    ax3 = fig.add_subplot(2, 2, 3)
    df['混合效应残差'] = model_mixed.resid
    top_groups = df['孕妇代码'].value_counts().index[:20]
    sns.boxplot(x='孕妇代码', y='混合效应残差', data=df[df['孕妇代码'].isin(top_groups)], ax=ax3)
    ax3.set_title('混合效应模型残差（按孕妇分组）')
    ax3.tick_params(axis='x', rotation=90)

    # 残差分布对比
    ax4 = fig.add_subplot(2, 2, 4)
    residuals = {
        'OLS': model_ols.resid,
        'Beta回归': y - model_beta.predict(X),
        '混合效应': model_mixed.resid
    }
    for name, res in residuals.items():
        sns.kdeplot(res, label=name, ax=ax4, shade=True)
    ax4.set_title('残差分布对比')
    plt.legend()

    plt.tight_layout()
    plt.savefig('模型诊断.png', dpi=300)
    plt.show()


model_diagnostics(model_ols, model_beta, model_mixed, df, X)


# ---------------------- 6. 结果保存（修改组间异质性方差的获取方式） ----------------------
def save_results(model_ols, model_beta, model_mixed, X):
    with open('模型结果.txt', 'w', encoding='utf-8') as f:
        # 普通线性回归
        f.write("===== 普通线性回归 =====\n")
        f.write(model_ols.summary().as_text() + "\n\n")
        f.write(f"残差正态性检验(p值): {lilliefors(model_ols.resid)[1]:.4f}\n\n")

        # 手动Beta回归
        f.write("===== Beta回归（手动实现） =====\n")
        f.write("系数:\n")
        for i, col in enumerate(X.columns):
            f.write(f"  {col}: {model_beta.coef_[i]:.6f}\n")
        f.write(f"\n对数似然值: {model_beta.log_likelihood_:.4f}\n")
        f.write(f"分散参数(alpha): {model_beta.alpha_:.4f}\n\n")

        # 混合效应模型（使用位置索引获取组间方差）
        f.write("===== 混合效应模型 =====\n")
        f.write(model_mixed.summary().as_text() + "\n\n")
        # 随机截距的协方差矩阵是1x1，直接取第一个元素（不依赖标签）
        group_variance = model_mixed.cov_re.iloc[0, 0]  # 按位置索引，兼容所有版本
        f.write(f"组间异质性方差: {group_variance:.4f}\n")


save_results(model_ols, model_beta, model_mixed, X)

print("分析完成，结果已保存至当前目录！")