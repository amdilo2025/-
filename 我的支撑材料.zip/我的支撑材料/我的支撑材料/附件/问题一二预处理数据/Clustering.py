# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import os
import pandas as pd
import numpy as np
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import warnings

warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False
# 定义输出目录
OUTPUT_DIR = "problem2_results"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def convert_gestational_week(week_str):
    if pd.isna(week_str):
        return np.nan
    s = str(week_str).strip().lower()
    try:
            week_part = s.split('w')[0].strip()
            day_part = s.split('w')[1].strip().replace('+', '').strip()
            weeks = float(week_part) if week_part else 0
            day_num = ''.join([c for c in day_part if c.isdigit()])
            days = float(day_num) if day_num else 0
            return round(weeks + days / 7, 2)
    except Exception:
        return np.nan
    return np.nan
#加载并预处理数据
def load_and_preprocess_data(file_path="C题数据.xlsx"):
    try:
        df = pd.read_excel(file_path)
        print(f"成功加载数据，原始样本数：{df.shape[0]}")
    except Exception as e:
        print(f"数据加载失败：{e}，使用模拟数据演示")

    male_df = df[df["Y染色体浓度"].notna()].copy()
    print(f"筛选男胎样本后，样本数：{male_df.shape[0]}")

    male_df["检测孕周数值"] = male_df["检测孕周"].apply(convert_gestational_week)

    key_cols = ["孕妇BMI", "检测孕周数值", "Y染色体浓度"]
    male_df = male_df[key_cols].dropna()  # 删除关键变量缺失样本
    print(f"孕周格式转换后，样本数：{male_df.shape[0]}")

    # 异常值处理（3σ准则）
    for col in key_cols:
        mean = male_df[col].mean()
        std = male_df[col].std()
        male_df = male_df[(male_df[col] >= mean - 3 * std) & (male_df[col] <= mean + 3 * std)]
    print(f"异常值处理后，样本数：{male_df.shape[0]}")

    male_df = male_df.rename(columns={"检测孕周数值": "检测孕周"})

    male_df.to_excel(os.path.join(OUTPUT_DIR, "preprocessed_data.xlsx"), index=False)
    return male_df

#BMI聚类分组
def bmi_clustering(df):
    bmi_data = df["孕妇BMI"].values.reshape(-1, 1)
    scaler = StandardScaler()
    bmi_scaled = scaler.fit_transform(bmi_data)

    # 确定最佳聚类数k（手肘法+轮廓系数）
    sse = []
    for k in range(2, 7):
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        kmeans.fit(bmi_scaled)
        sse.append(kmeans.inertia_)

    # 绘制手肘图
    plt.figure(figsize=(10, 6))
    plt.plot(range(2, 7), sse, 'bo-')
    plt.xlabel("聚类数k")
    plt.ylabel("总误差平方和(SSE)")
    plt.title("手肘法确定最佳聚类数")
    plt.savefig(os.path.join(OUTPUT_DIR, "elbow_method.png"), dpi=300)
    plt.show()

    # 选择最佳k=3
    best_k = 3
    kmeans = KMeans(n_clusters=best_k, random_state=42, n_init=10)
    df["BMI分组"] = kmeans.fit_predict(bmi_scaled)

    # 按BMI值排序分组标签
    cluster_centers = scaler.inverse_transform(kmeans.cluster_centers_)
    sorted_clusters = np.argsort(cluster_centers.flatten())
    cluster_mapping = {old: new for new, old in enumerate(sorted_clusters)}
    df["BMI分组"] = df["BMI分组"].map(cluster_mapping)

    # 计算每组BMI区间
    groups = []
    for i in range(best_k):
        group_data = df[df["BMI分组"] == i]["孕妇BMI"]
        min_bmi = group_data.min()
        max_bmi = group_data.max()
        groups.append({
            "BMI分组": i,
            "BMI区间": [min_bmi, max_bmi],
            "样本数": len(group_data),
            "占比": len(group_data) / len(df)
        })
    groups_df = pd.DataFrame(groups)
    print("\nBMI分组结果：")
    print(groups_df)
    groups_df.to_excel(os.path.join(OUTPUT_DIR, "bmi_groups.xlsx"), index=False)

    # 可视化分组结果
    plt.figure(figsize=(12, 6))
    sns.boxplot(x="BMI分组", y="孕妇BMI", data=df)
    plt.xlabel("BMI分组（0：低BMI组，1：中BMI组，2：高BMI组）")
    plt.ylabel("BMI值（kg/m²）")
    plt.title("BMI分组箱线图")
    plt.savefig(os.path.join(OUTPUT_DIR, "bmi_groups_boxplot.png"), dpi=300)
    plt.show()

    return df, groups_df


def calculate_earliest_达标时间(df):
    """计算每组最早达标时间（Y染色体浓度≥4%的最早孕周）"""
    # 确保浓度单位正确（转换为百分比）
    if df["Y染色体浓度"].max() < 1:  # 若数据为比例形式（如0.05代表5%）
        df["Y染色体浓度百分比"] = df["Y染色体浓度"] * 100
    else:
        df["Y染色体浓度百分比"] = df["Y染色体浓度"]

    # 按孕妇ID分组（假设存在重复检测，这里简化为按BMI分组+孕周排序）
    # 实际应用中应按孕妇唯一标识（如"孕妇代码"）分组
    earliest_times = []
    for group_id in df["BMI分组"].unique():
        group_data = df[df["BMI分组"] == group_id].copy()
        # 按孕周升序排序，找到首次达标时间
        group_data = group_data.sort_values("检测孕周")
        达标样本 = group_data[group_data["Y染色体浓度百分比"] >= 4]
        if len(达标样本) == 0:
            earliest_time = np.nan  # 无达标样本
        else:
            earliest_time = 达标样本["检测孕周"].min()
        earliest_times.append({
            "BMI分组": group_id,
            "最早达标时间(周)": earliest_time,
            "达标样本数": len(达标样本),
            "达标率": len(达标样本) / len(group_data)
        })

    earliest_df = pd.DataFrame(earliest_times)
    print("\n各组最早达标时间：")
    print(earliest_df)
    earliest_df.to_excel(os.path.join(OUTPUT_DIR, "earliest达标时间.xlsx"), index=False)

    # 可视化达标时间分布
    plt.figure(figsize=(12, 6))
    sns.violinplot(x="BMI分组", y="检测孕周", hue=(df["Y染色体浓度百分比"] >= 4),
                   data=df, split=True, inner="quartile")
    plt.xlabel("BMI分组")
    plt.ylabel("检测孕周")
    plt.title("不同BMI分组的孕周与达标状态分布")
    plt.legend(title="是否达标", labels=["未达标", "达标"])
    plt.savefig(os.path.join(OUTPUT_DIR, "达标时间分布.png"), dpi=300)
    plt.show()

    return df, earliest_df


def optimize_detection_time(earliest_df):
    """
    优化最佳检测时点：
    1. 定义风险函数
    2. 结合最早达标时间确定最佳时点
    """

    # 定义风险函数（根据临床风险分级）
    def risk_function(week):
        if week <= 12:
            return 0.1  # 早期风险低
        elif 13 <= week <= 27:
            return 0.5  # 中期风险高
        else:
            return 0.9  # 晚期风险极高

    # 计算每组最佳时点（最早达标时间与最低风险的平衡）
    optimal_times = []
    for _, row in earliest_df.iterrows():
        group_id = row["BMI分组"]
        earliest_time = row["最早达标时间(周)"]

        # 若最早达标时间在早期（≤12周），直接选择该时间
        if earliest_time <= 12:
            optimal_time = earliest_time
        # 若在中期，选择最早达标时间
        elif 13 <= earliest_time <= 27:
            optimal_time = earliest_time
        # 若在晚期，需权衡（这里选择27周作为最晚中期时间）
        else:
            optimal_time = 27  # 避免进入晚期高风险

        risk = risk_function(optimal_time)
        optimal_times.append({
            "BMI分组": group_id,
            "最早达标时间(周)": earliest_time,
            "最佳检测时点(周)": optimal_time,
            "对应风险值": risk
        })
    optimal_df = pd.DataFrame(optimal_times)
    print("\n最佳检测时点优化结果：")
    print(optimal_df)
    optimal_df.to_excel(os.path.join(OUTPUT_DIR, "optimal_detection_times.xlsx"), index=False)

    # 可视化风险与时点关系
    plt.figure(figsize=(12, 6))
    weeks = np.linspace(10, 25, 100)
    risks = [risk_function(w) for w in weeks]
    plt.plot(weeks, risks, 'r-', label="风险函数")
    for _, row in optimal_df.iterrows():
        plt.scatter(row["最佳检测时点(周)"], row["对应风险值"],
                    s=100, label=f"分组{row['BMI分组']}最佳时点")
    plt.xlabel("孕周")
    plt.ylabel("风险值")
    plt.title("最佳检测时点与风险函数关系")
    plt.legend()
    plt.savefig(os.path.join(OUTPUT_DIR, "risk_vs_time.png"), dpi=300)
    plt.show()

    return optimal_df


def error_sensitivity_analysis(df, optimal_df):
    """分析检测误差对结果的影响（蒙特卡洛模拟）"""
    # 转换浓度为百分比
    if "Y染色体浓度百分比" not in df.columns:
        df["Y染色体浓度百分比"] = df["Y染色体浓度"] * 100 if df["Y染色体浓度"].max() < 1 else df["Y染色体浓度"]

    # 模拟检测误差（±5%浓度扰动）
    n_sim = 1000  # 模拟次数
    error_results = []
    for group_id in df["BMI分组"].unique():
        group_data = df[df["BMI分组"] == group_id]
        original_earliest = optimal_df[optimal_df["BMI分组"] == group_id]["最早达标时间(周)"].values[0]

        # 蒙特卡洛模拟
        simulated_times = []
        for _ in range(n_sim):
            # 添加±5%的浓度误差
            perturbed_conc = group_data["Y染色体浓度百分比"] * (1 + np.random.uniform(-0.05, 0.05))
            perturbed_df = group_data.copy()
            perturbed_df["扰动后浓度"] = perturbed_conc
            # 计算扰动后的最早达标时间
            达标样本 = perturbed_df[perturbed_df["扰动后浓度"] >= 4].sort_values("检测孕周")
            if len(达标样本) > 0:
                simulated_times.append(达标样本["检测孕周"].min())

        # 统计模拟结果
        if simulated_times:
            mean_time = np.mean(simulated_times)
            std_time = np.std(simulated_times)
            ci_low = np.percentile(simulated_times, 2.5)
            ci_high = np.percentile(simulated_times, 97.5)
        else:
            mean_time = np.nan
            std_time = np.nan
            ci_low = np.nan
            ci_high = np.nan

        error_results.append({
            "BMI分组": group_id,
            "原始最早达标时间": original_earliest,
            "模拟平均达标时间": mean_time,
            "标准差": std_time,
            "95%置信区间": [ci_low, ci_high]
        })
    error_df = pd.DataFrame(error_results)
    print("\n检测误差敏感性分析结果：")
    print(error_df)
    error_df.to_excel(os.path.join(OUTPUT_DIR, "error_analysis.xlsx"), index=False)

    # 可视化误差影响
    plt.figure(figsize=(12, 6))
    x = error_df["BMI分组"]
    y_original = error_df["原始最早达标时间"]
    y_mean = error_df["模拟平均达标时间"]
    y_err = error_df["标准差"]
    plt.errorbar(x, y_mean, yerr=y_err, fmt='bo-', label="模拟均值±标准差")
    plt.scatter(x, y_original, c='r', s=100, label="原始值")
    plt.xlabel("BMI分组")
    plt.ylabel("最早达标时间(周)")
    plt.title("检测误差对最早达标时间的影响")
    plt.legend()
    plt.savefig(os.path.join(OUTPUT_DIR, "error_impact.png"), dpi=300)
    plt.show()

    return error_df


def main():
    """主函数：整合数据处理、聚类分组、时点优化和误差分析流程"""
    # 1. 数据加载与预处理
    df = load_and_preprocess_data()

    # 2. BMI聚类分组
    df, groups_df = bmi_clustering(df)

    # 3. 计算最早达标时间
    df, earliest_df = calculate_earliest_达标时间(df)

    # 4. 优化最佳检测时点
    optimal_df = optimize_detection_time(earliest_df)

    # 5. 检测误差敏感性分析
    error_df = error_sensitivity_analysis(df, optimal_df)

    # 输出最终结果汇总
    final_result = pd.merge(groups_df, optimal_df, on="BMI分组")
    final_result = pd.merge(final_result, error_df[["BMI分组", "标准差", "95%置信区间"]], on="BMI分组")
    final_result.to_excel(os.path.join(OUTPUT_DIR, "final_result_summary.xlsx"), index=False)
    print("\n最终结果汇总：")
    print(final_result)
    print(f"\n所有结果已保存至 {OUTPUT_DIR} 目录")


if __name__ == "__main__":
    main()