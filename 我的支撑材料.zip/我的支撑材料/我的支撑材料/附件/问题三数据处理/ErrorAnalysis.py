# -*- coding: utf-8 -*-
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import qmc
import warnings

warnings.filterwarnings('ignore')

# 设置中文显示，增加更多字体选项确保兼容性
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False
plt.style.use('seaborn-v0_8-talk')

# 定义输出目录（用于保存图形）
OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# -------------------------- 误差分析 --------------------------
def error_analysis(cluster_data, top_features, optiminal_timing, best_k):
    if cluster_data is None or cluster_data.empty or optimal_timing is None or best_k is None:
        print("无数据用于误差分析")
        return

    undulation = {f: 0.1 for f in top_features}
    n_features = len(top_features)

    sampler = qmc.LatinHypercube(d=n_features, seed=42)
    sample = sampler.random(n=1000)

    mean = cluster_data[top_features].mean().values
    scope = np.array([mean[i] * undulation[top_features[i]] for i in range(n_features)])
    lhs_samples = qmc.scale(sample, mean - scope, mean + scope)

    change = {cluster: [] for cluster in optiminal_timing['聚类组']}
    for i in range(1000):
        delta = lhs_samples[i] - mean
        delta_ratio = np.mean(delta / mean)

        for _, row in optiminal_timing.iterrows():
            cluster = row['聚类组']
            base_t = row['最佳时点(周)']
            new_t = base_t * (1 + delta_ratio * 0.3)
            new_t = np.clip(new_t, 10, 25)  # 确保在有效范围内
            change[cluster].append(new_t - base_t)

    sobol = {}
    for cluster in change:
        variance = np.var(change[cluster])
        sobol[cluster] = variance / sum(np.var(v) for v in change.values())

    # 绘制Sobol指数图
    plt.figure(figsize=(10, 6))
    sns.barplot(x=list(sobol.keys()), y=list(sobol.values()), palette='Reds')
    plt.title('各聚类组最佳时点对误差的敏感度（Sobol指数）')
    plt.xlabel('聚类组')
    plt.ylabel('Sobol指数')
    plt.savefig(os.path.join(OUTPUT_DIR, '7_误差分析_Sobol指数.png'))
    plt.show()
    plt.close()

    # 保存误差分析结果
    result = pd.DataFrame({
        '聚类组': list(sobol.keys()),
        'Sobol指数': list(sobol.values())
    })
    output_path = os.path.join(OUTPUT_DIR, '7_误差分析结果.xlsx')
    result.to_excel(output_path, index=False)
    print("误差分析结果已保存")


if __name__ == "__main__":
    try:
        # 加载最佳时点结果
        optimal_timing_path = os.path.join(OUTPUT_DIR, '6_最佳时点结果.xlsx')
        optimal_timing = pd.read_excel(optimal_timing_path)
        print(f"成功加载最佳时点结果：{optimal_timing_path}")

        # 加载Top3特征（从特征重要性结果读取）
        importance_path = os.path.join(OUTPUT_DIR, '3_特征重要性得分.xlsx')
        importance_df = pd.read_excel(importance_path)
        top3_features = importance_df['特征'].head(3).tolist()
        print(f"成功加载Top3特征：{top3_features}")

        # 加载聚类结果数据
        cluster_result_path = os.path.join(OUTPUT_DIR, '4_聚类结果数据.xlsx')
        cluster_result = pd.read_excel(cluster_result_path)
        print(f"成功加载聚类结果：{cluster_result_path}")

        # 加载最佳聚类数（示例：从聚类结果中推断，或单独保存）
        best_k = len(cluster_result['聚类标签'].unique())
        print(f"最佳聚类数：{best_k}")

    except Exception as e:
        print(f"数据加载失败：{e}")
        optimal_timing = None
        top3_features = None
        cluster_result = None
        best_k = None

    # 调用误差分析函数（注意修复拼写错误）
    if optimal_timing is not None and top3_features and cluster_result is not None and best_k is not None:
        error_analysis(cluster_result, top3_features, optimal_timing, best_k)
    else:
        print("缺少必要输入数据，无法执行误差分析")