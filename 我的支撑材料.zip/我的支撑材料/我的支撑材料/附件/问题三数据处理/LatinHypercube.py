import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import qmc
from sklearn.ensemble import RandomForestRegressor  # 导入随机森林回归器
import warnings
import joblib

warnings.filterwarnings('ignore')

# 设置中文显示
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False
plt.style.use('seaborn-v0_8-talk')

# 定义输出目录
OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)


# -------------------------- 8. 误差分析（增强特征波动影响） --------------------------
def error_analysis(cluster_data, optimal_timing, regression_models, best_k):
    if optimal_timing is None or optimal_timing.empty or not regression_models:
        print("无有效数据用于误差分析")
        return

    # 进一步扩大特征波动范围（增强敏感性）
    feature_ranges = {
        '年龄': (-8, 8),  # 年龄波动±8岁
        '体重': (-10, 10),  # 体重波动±10kg
        '孕妇BMI': (-5, 5)  # BMI波动±5
    }
    features = list(feature_ranges.keys())

    # 提取每个聚类组的基准特征均值
    cluster_base_features = {}
    for cluster in range(best_k):
        cluster_subset = cluster_data[cluster_data['聚类标签'] == cluster]
        if cluster_subset.empty or cluster not in regression_models:
            continue
        cluster_base_features[cluster] = {f: cluster_subset[f].mean() for f in features}

    # 拉丁超立方采样（增加样本量，覆盖更多波动组合）
    n_samples = 2000
    sampler = qmc.LatinHypercube(d=len(features), seed=42)
    sample = sampler.random(n=n_samples)

    # 缩放采样到特征波动区间
    lhs_samples = []
    for i in range(n_samples):
        single_sample = sample[i].reshape(1, -1)
        lows = [feature_ranges[f][0] for f in features]
        highs = [feature_ranges[f][1] for f in features]
        scaled_sample = qmc.scale(single_sample, lows, highs)
        lhs_samples.append(scaled_sample[0])
    lhs_samples = np.array(lhs_samples)

    # 风险函数（与最佳时点计算一致）
    def risk(week):
        if week <= 12:
            return 1 + (week - 10) * 0.05
        elif 13 <= week <= 27:
            return 2 + (week - 13) * 0.03
        else:
            return 3

    # 计算特征波动后的最佳时点变化（使用随机森林预测）
    cluster_changes = {cluster: [] for cluster in cluster_base_features}
    for sample_idx in range(n_samples):
        feature_changes = lhs_samples[sample_idx]
        for cluster, base_features in cluster_base_features.items():
            if cluster not in regression_models:
                continue
            model = regression_models[cluster]  # 随机森林模型（无需多项式和标准化组件）
            base_t = optimal_timing[optimal_timing['聚类组'] == cluster]['最佳时点(周)'].values[0]

            # 遍历孕周，寻找新最佳时点（细化步长）
            best_t_new, best_obj_new = None, float('inf')
            t_range = np.arange(10, 25.01, 0.01)  # 步长0.01周，提高精度
            for t in t_range:
                # 当前特征 = 基准 + 波动（随机森林直接使用原始特征）
                current_features = [t] + [base_features[f] + feature_changes[i] for i, f in enumerate(features)]
                X_test = np.array(current_features).reshape(1, -1)  # 无需标准化和多项式转换

                # 随机森林预测达标比例
                prop = model.predict(X_test)[0]
                prop = max(0.01, min(0.99, prop))  # 限制概率范围

                # 目标函数（与最佳时点计算一致）
                obj = 0.3 * risk(t) + 0.7 * (1 - prop)
                if obj < best_obj_new:
                    best_obj_new = obj
                    best_t_new = round(t, 2)

            # 计算变化量（保留2位小数）
            change = best_t_new - base_t
            cluster_changes[cluster].append(change)

    # 计算Sobol指数（分析特征影响）
    sobol_indices = {}
    for cluster in cluster_changes:
        if not cluster_changes[cluster]:
            continue
        # 计算总方差
        total_variance = np.var(cluster_changes[cluster], ddof=1)  # 样本方差（除以n-1）
        print(f"聚类组{cluster}的最佳时点变化量总方差：{total_variance:.6f}")
        if total_variance < 1e-8:
            sobol_indices[cluster] = {f: 0.0 for f in features}
            continue

        # 计算单特征方差贡献
        feature_variances = {}
        for j, f in enumerate(features):
            feature_effects = []
            for val in lhs_samples[:, j]:
                fake_changes = np.zeros(len(features))
                fake_changes[j] = val
                current_features = [base_features[f] + fake_changes[i] for i, f in enumerate(features)]

                model = regression_models[cluster]
                base_t = optimal_timing[optimal_timing['聚类组'] == cluster]['最佳时点(周)'].values[0]

                # 寻找该特征波动下的最佳时点
                best_t_new, best_obj_new = None, float('inf')
                t_range = np.arange(10, 25.01, 0.01)
                for t in t_range:
                    X_test = np.array([t] + current_features).reshape(1, -1)  # 直接使用原始特征
                    prop = model.predict(X_test)[0]
                    prop = max(0.01, min(0.99, prop))
                    obj = 0.3 * risk(t) + 0.7 * (1 - prop)
                    if obj < best_obj_new:
                        best_obj_new = obj
                        best_t_new = round(t, 2)

                change = best_t_new - base_t
                feature_effects.append(change)

            feature_variances[f] = np.var(feature_effects, ddof=1)
            print(f"  特征{f}的方差贡献：{feature_variances[f]:.6f}")

        # 计算Sobol指数
        sobol = {f: var / total_variance for f, var in feature_variances.items()}
        sobol_indices[cluster] = sobol
        print(f"聚类组{cluster}的Sobol指数：{sobol}")

    # 可视化Sobol指数
    for cluster in sobol_indices:
        plt.figure(figsize=(10, 6))
        sns.barplot(
            x=list(sobol_indices[cluster].keys()),
            y=list(sobol_indices[cluster].values()),
            palette='Reds'
        )
        plt.title(f'聚类组{cluster} - 特征对最佳时点的影响（Sobol指数）')
        plt.xlabel('特征')
        plt.ylabel('Sobol指数（值越大，影响越强）')
        plt.tight_layout()
        plot_path = os.path.join(OUTPUT_DIR, f'8_误差分析_聚类组{cluster}_Sobol指数.png')
        plt.savefig(plot_path, dpi=300)
        plt.close()
        print(f"聚类组{cluster}的Sobol指数图已保存至：{plot_path}")

    # 保存结果
    all_sobol = []
    for cluster in sobol_indices:
        for f, val in sobol_indices[cluster].items():
            all_sobol.append({
                '聚类组': cluster,
                '特征': f,
                'Sobol指数': val
            })
    if all_sobol:
        result_df = pd.DataFrame(all_sobol)
        output_path = os.path.join(OUTPUT_DIR, '8_误差分析_Sobol指数结果.xlsx')
        result_df.to_excel(output_path, index=False)
        print(f"Sobol指数结果已保存至：{output_path}")

    print("误差分析完成")
    return sobol_indices


# -------------------------- 主函数 --------------------------
if __name__ == "__main__":
    try:
        # 加载数据
        preprocessed_path = os.path.join(OUTPUT_DIR, '1_预处理后数据.xlsx')
        preprocessed_data = pd.read_excel(preprocessed_path)
        print(f"成功加载预处理数据：{preprocessed_path}，共{len(preprocessed_data)}条")

        # 特征统计与相关性
        print("\n特征统计分布：")
        for col in ['年龄', '体重', '孕妇BMI', 'Y染色体浓度']:
            desc = preprocessed_data[col].describe()
            print(f"\n{col}：")
            print(f"  均值：{desc['mean']:.2f}，标准差：{desc['std']:.2f}，变异系数：{desc['std'] / desc['mean']:.2f}")
            print(f"  最小值：{desc['min']:.2f}，最大值：{desc['max']:.2f}")

        print("\nY染色体浓度与特征的相关性：")
        for col in ['年龄', '体重', '孕妇BMI']:
            corr = preprocessed_data[[col, 'Y染色体浓度']].corr().iloc[0, 1]
            print(f"{col}与Y染色体浓度的相关系数：{corr:.4f}")

        # 加载聚类结果
        cluster_result_path = os.path.join(OUTPUT_DIR, '4_聚类结果数据.xlsx')
        cluster_result = pd.read_excel(cluster_result_path)
        print(f"成功加载聚类结果：{cluster_result_path}，共{len(cluster_result)}条")

        best_k = len(cluster_result['聚类标签'].unique())
        print(f"最佳聚类数：{best_k}")

        # 加载最佳时点结果
        optimal_timing_path = os.path.join(OUTPUT_DIR, '6_最佳时点结果.xlsx')
        optimal_timing = pd.read_excel(optimal_timing_path)
        print(f"成功加载最佳时点结果：{optimal_timing_path}，共{len(optimal_timing)}条")

        # 加载或训练随机森林回归模型（核心改进点）
        regression_models = {}
        for cluster in range(best_k):
            model_path = os.path.join(OUTPUT_DIR, f'random_forest_model_cluster_{cluster}.pkl')  # 修改模型文件名
            if os.path.exists(model_path):
                model = joblib.load(model_path)  # 随机森林模型无需额外组件
                regression_models[cluster] = model
            else:
                print(f"随机森林模型文件 {model_path} 不存在，重新训练模型")
                cluster_subset = preprocessed_data.copy()
                # 合并聚类结果数据以获取聚类标签
                cluster_subset = cluster_subset.merge(cluster_result[['孕妇代码', '聚类标签']], on='孕妇代码',
                                                      how='left')
                cluster_subset = cluster_subset[cluster_subset['聚类标签'] == cluster]
                if cluster_subset.empty:
                    print(f"警告：聚类组{cluster}无有效数据，跳过")
                    continue

                # 计算达标比例（Y染色体浓度≥0.04）
                cluster_subset['达标比例'] = (cluster_subset['Y染色体浓度'] >= 0.04).astype(float)
                if len(cluster_subset) < 10:
                    print(f"聚类组{cluster}样本量不足（<10），跳过训练")
                    continue

                # 随机森林使用原始特征（无需标准化和多项式扩展）
                X = cluster_subset[['孕周数值', '年龄', '体重', '孕妇BMI']].values  # 直接使用原始特征
                y = cluster_subset['达标比例'].values

                # 训练随机森林回归器（设置合适参数）
                model = RandomForestRegressor(
                    n_estimators=100,  # 树的数量
                    max_depth=8,  # 控制过拟合
                    min_samples_split=5,  # 分裂节点最小样本数
                    random_state=42,  # 固定随机种子保证可复现性
                    n_jobs=-1  # 并行计算
                )
                model.fit(X, y)  # 直接拟合原始特征

                # 保存随机森林模型
                regression_models[cluster] = model
                joblib.dump(model, model_path)
                print(f"已重新训练并保存聚类组{cluster}的随机森林模型至 {model_path}")

    except Exception as e:
        print(f"数据加载失败：{e}")
        preprocessed_data = None
        cluster_result = None
        best_k = None
        optimal_timing = None
        regression_models = {}

    # 执行误差分析
    if preprocessed_data is not None and cluster_result is not None and best_k is not None and optimal_timing is not None and regression_models:
        error_analysis(cluster_result, optimal_timing, regression_models, best_k)
    else:
        print("缺少必要数据，无法执行误差分析")