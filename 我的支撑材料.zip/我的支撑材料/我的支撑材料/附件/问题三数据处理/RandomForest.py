# -*- coding: utf-8 -*-
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
import warnings

warnings.filterwarnings('ignore')

# 设置中文显示，增加更多字体选项确保兼容性
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False
plt.style.use('seaborn-v0_8-talk')

# 定义输出目录（用于保存图形）
OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# -------------------------- 3. 随机森林特征重要性筛选 --------------------------
def select_features(complaince_data):
    if complaince_data is None or complaince_data.empty:
        print("无数据用于特征筛选")
        return None, None

    # 修正特征列名，与之前的"孕妇BMI"保持一致
    feature_columns = ['年龄', '身高', '体重', '怀孕次数', '生产次数', '孕妇BMI']
    # 检查特征列是否都存在于数据中
    missing_cols = [col for col in feature_columns if col not in complaince_data.columns]
    if missing_cols:
        print(f"数据中缺少特征列：{missing_cols}")
        return None, None

    X = complaince_data[feature_columns]
    y = complaince_data['达标比例']  # 确保数据中存在"达标比例"列

    rf = RandomForestRegressor(n_estimators=200, random_state=42)
    rf.fit(X, y)

    importance = pd.DataFrame({
        '特征': feature_columns,
        '重要性得分': rf.feature_importances_
    }).sort_values(by='重要性得分', ascending=False)

    plt.figure(figsize=(10, 6))
    sns.barplot(x='重要性得分', y='特征', data=importance, palette='YlOrBr')
    plt.title('各特征对Y染色体达标比例的重要性')
    plt.tight_layout()

    # 先保存再关闭，避免显示导致的缓存问题
    output_path = os.path.join(OUTPUT_DIR, '3_特征重要性.png')
    plt.savefig(output_path)
    plt.close()  # 优先保存，如需显示可在save后加plt.show()

    # 保存重要性得分（改为Excel格式）
    importance_path = os.path.join(OUTPUT_DIR, '3_特征重要性得分.xlsx')
    importance.to_excel(importance_path, index=False)  # 改为to_excel方法

    top3_features = importance['特征'].head(3).tolist()
    print(f"第三部分结果：前三重要特征为{top3_features}")
    return complaince_data, top3_features


# -------------------------- 主函数 --------------------------
if __name__ == "__main__":
    # 加载之前生成的"达标比例数据"
    compliance_data_path = os.path.join(OUTPUT_DIR, '2_达标比例数据.xlsx')
    try:
        complaince_data = pd.read_excel(compliance_data_path)
        print("成功加载达标比例数据")
    except Exception as e:
        print(f"加载达标比例数据失败：{e}")
        complaince_data = None

    # 调用特征筛选函数
    feature_data, top3_features = select_features(complaince_data)
    if top3_features:
        print(f"选中的前三特征: {top3_features}")