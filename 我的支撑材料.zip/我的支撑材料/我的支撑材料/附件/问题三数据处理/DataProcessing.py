import pandas as pd
import numpy as np
import os

# 确保输出目录存在
output_dir = "results"
os.makedirs(output_dir, exist_ok=True)


def preprocess_week(week_str):
    """将孕周字符串（支持多种格式）转换为浮点数值（单位：周）"""
    if pd.isna(week_str):
        return np.nan

    # 统一转为字符串并处理大小写和空格
    week_str = str(week_str).strip().lower()

    try:
        # 分割周数和天数部分
        week_part = week_str.split('w')[0].strip()
        day_part = week_str.split('w')[1].strip().replace('+', '').strip()

        # 解析周数
        weeks = float(week_part) if week_part else 0

        # 解析天数（如果存在）
        day = 0

        return round(weeks + day / 7, 2)  # 转换为周并保留2位小数

    # 所有无法解析的格式返回NaN
    except:
        return np.nan


def load_and_preprocess_data():
    """加载并预处理数据"""
    # 读取数据
    try:
        df = pd.read_excel("C题数据.xlsx")
        print("数据加载成功，原始数据 shape:", df.shape)
    except Exception as e:
        print(f"数据加载失败: {e}")

    # 数据清洗
    # 1. 检查并提取关键变量
    required_cols = ["孕妇代码", "年龄", "身高", "体重", "怀孕次数", "生产次数", "检测孕周", "孕妇BMI", "Y染色体浓度"]
    # 处理列名可能的空格或大小写问题
    df.columns = [col.strip() for col in df.columns]
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"数据缺少必要列: {missing_cols}，需包含{required_cols}")
    df = df[required_cols].copy()

    # 2. 转换孕周为数值（核心步骤：生成浮点型孕周数值）
    df["孕周数值"] = df["检测孕周"].apply(preprocess_week)
    # 验证转换后的数据类型
    print(f"\n孕周数值列数据类型: {df['孕周数值'].dtype}（应为float64）")

    # 3. 处理缺失值
    print(f"\n缺失值统计:")
    print(df.isnull().sum())
    # 保留关键变量非缺失的样本
    df = df.dropna(subset=["孕周数值", "孕妇BMI", "Y染色体浓度"])
    print(f"删除缺失值后样本量: {df.shape[0]}")

    # 4. 处理异常值（3σ准则，同时结合临床合理范围）
    # 孕周合理范围：10 - 25 周（临床常识）
    df = df[(df["孕周数值"] >= 10) & (df["孕周数值"] <= 25)]
    # BMI 合理范围：15 - 40（生理合理范围）
    df = df[(df["孕妇BMI"] >= 15) & (df["孕妇BMI"] <= 40)]

    # 对 Y 染色体浓度使用 3σ 准则
    if len(df) >= 3:  # 确保样本量足够
        y_mean = df["Y染色体浓度"].mean()
        y_std = df["Y染色体浓度"].std()
        df = df[(df["Y染色体浓度"] >= y_mean - 3 * y_std) & (df["Y染色体浓度"] <= y_mean + 3 * y_std)]

    # 处理怀孕次数为字符串的情况，将其全部存储为 3
    def handle_pregnancy_count(x):
        if isinstance(x, str):
            return 3
        return x

    df['怀孕次数'] = df['怀孕次数'].apply(handle_pregnancy_count)

    print(f"剔除异常值后样本量: {df.shape[0]}")

    # 5. 重置索引
    df = df.reset_index(drop=True)

    return df


def main():
    # 加载并预处理数据（含孕周转换）
    df = load_and_preprocess_data()

    # 保存预处理后的数据（包含浮点型孕周数值）
    output_path = os.path.join(output_dir, "1_预处理后数据.xlsx")
    df.to_excel(output_path, index=False)
    print(f"\n预处理后的数据已保存至: {output_path}")


if __name__ == "__main__":
    main()