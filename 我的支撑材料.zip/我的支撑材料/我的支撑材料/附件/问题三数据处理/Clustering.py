# -*- coding: utf-8 -*-
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
import warnings

warnings.filterwarnings('ignore')

# 设置中文显示，增加更多字体选项确保兼容性
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False
plt.style.use('seaborn-v0_8-talk')

# 定义输出目录（用于保存图形）
OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)


# -------------------------- 4. K-Means聚类分组 --------------------------
def cluster_groups(data, top_features):
    if data is None or data.empty:
        print("无数据用于聚类")
        return None, None, None
    if not top_features:
        print("未提供有效特征列表")
        return None, None, None

    # 检查top_features是否都存在于data中
    missing_features = [f for f in top_features if f not in data.columns]
    if missing_features:
        print(f"数据中缺少特征：{missing_features}")
        return None, None, None

    X = data[top_features]
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    inertias = []
    sil_scores = []
    k_range = range(2, 9)  # 聚类数范围可根据实际数据调整
    for k in k_range:
        kmeans = KMeans(n_clusters=k, n_init=10, random_state=42)  # 指定n_init避免警告
        labels = kmeans.fit_predict(X_scaled)
        inertias.append(kmeans.inertia_)
        sil_scores.append(silhouette_score(X_scaled, labels))

    # 绘制肘部法则和轮廓系数图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    ax1.plot(k_range, inertias, 'bo-', markerfacecolor='r')
    ax1.set_title('肘部法则（Inertia）')
    ax1.set_xlabel('聚类数k')
    ax2.plot(k_range, sil_scores, 'go-', markerfacecolor='r')
    ax2.set_title('轮廓系数')
    ax2.set_xlabel('聚类数k')
    plt.tight_layout()

    # 保存图像（先保存再显示）
    output_path = os.path.join(OUTPUT_DIR, '4_聚类数选择.png')
    plt.savefig(output_path, dpi=300)  # 增加dpi确保清晰度
    plt.show()
    plt.close()

    # 确定最佳聚类数
    if max(sil_scores) < 0.2:  # 轮廓系数低于0.2，聚类效果差
        print("警告：聚类效果不佳（轮廓系数<0.2），使用默认k=2")
        best_k = 2
    else:
        best_k = k_range[np.argmax(sil_scores)]  # 取轮廓系数最大的k

    # 执行最终聚类并添加标签
    kmeans = KMeans(n_clusters=best_k, n_init=10, random_state=42)
    data = data.copy()  # 避免修改原数据的警告
    data['聚类标签'] = kmeans.fit_predict(X_scaled)

    # 保存聚类结果（可根据需要改为Excel格式）
    output_path = os.path.join(OUTPUT_DIR, '4_聚类结果数据.xlsx')
    data.to_excel(output_path, index=False)  # 改为Excel格式
    np.save(os.path.join(OUTPUT_DIR, 'X_scaled.npy'), X_scaled)
    print(f"第四部分结果：最佳聚类数k={best_k}")
    return data, best_k, X_scaled


# -------------------------- 主函数 --------------------------
if __name__ == "__main__":
    # 1. 加载聚类所需数据（假设从之前的特征重要性结果中获取）
    try:
        # 加载包含特征的数据（例如之前的"达标比例数据"）
        data_path = os.path.join(OUTPUT_DIR, '2_达标比例数据.xlsx')
        feature_data = pd.read_excel(data_path)
        print("成功加载聚类数据")
    except Exception as e:
        print(f"加载聚类数据失败：{e}")
        feature_data = None

    # 2. 加载前三重要特征（可从特征重要性结果中读取，或手动指定）
    try:
        # 从特征重要性得分文件中读取前三特征
        importance_path = os.path.join(OUTPUT_DIR, '3_特征重要性得分.xlsx')
        importance_df = pd.read_excel(importance_path)
        top3_features = importance_df['特征'].head(3).tolist()
        print(f"成功加载前三特征：{top3_features}")
    except Exception as e:
        print(f"加载前三特征失败，使用默认特征：{e}")
        top3_features = ['年龄', '体重', '孕妇BMI']  # 备选默认特征

    # 3. 执行聚类
    cluster_result, best_k, X_scaled = cluster_groups(feature_data, top3_features)