import os
import pandas as pd
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')

# 定义输出目录（用于保存图形）
OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)


# -------------------------- 2. 计算个体达标比例 --------------------------
def calculate_complaince_rate(preprocessed_df):
    if preprocessed_df is None or preprocessed_df.empty:
        print("无有效数据用于计算达标比例")
        return None

    grouped = preprocessed_df.groupby('孕妇代码')
    complaince_rate_data = pd.DataFrame()

    complaince_rate_data['孕妇代码'] = grouped.groups.keys()
    complaince_rate_data['总检测次数'] = grouped.size().values

    try:
        # 文档中 4% 为达标阈值
        compliance_number = grouped.apply(lambda x: sum(x['Y染色体浓度'] >= 0.04))
        complaince_rate_data['达标次数'] = compliance_number.values
        complaince_rate_data['达标比例'] = complaince_rate_data['达标次数'] / complaince_rate_data['总检测次数']
    except Exception as e:
        print(f"计算达标比例出错: {e}")
        return None

    feature_columns = ['年龄', '身高', '体重', '怀孕次数', '生产次数', '孕妇BMI']

    for col, chinese_col in zip(feature_columns, feature_columns):
        complaince_rate_data[chinese_col] = grouped[col].mean().values

    # 保存到输出目录，修正保存方法为 to_excel
    output_path = os.path.join(OUTPUT_DIR, '2_达标比例数据.xlsx')
    complaince_rate_data.to_excel(output_path, index=False)
    print("第二部分结果：达标比例数据已保存")
    return complaince_rate_data


# -------------------------- 主函数 --------------------------
if __name__ == "__main__":
    preprocessed_data_path = "results/1_预处理后数据.xlsx"
    preprocessed_data = pd.read_excel(preprocessed_data_path)
    complaince_data = calculate_complaince_rate(preprocessed_data)