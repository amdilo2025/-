# -*- coding: utf-8 -*-
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

warnings.filterwarnings('ignore')

# 设置中文显示，增加更多字体选项确保兼容性
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False
plt.style.use('seaborn-v0_8-talk')

# 定义输出目录（用于保存图形）
OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)


# -------------------------- 6. 最佳时点计算 --------------------------
def find_best_time(data, cluster_data, best_k):
    # 检查输入数据是否有效
    if data is None or data.empty:
        print("错误：预处理数据为空或未定义")
        return None
    if cluster_data is None or cluster_data.empty:
        print("错误：聚类结果数据为空或未定义")
        return None
    if best_k is None or best_k < 2:
        print(f"错误：无效的最佳聚类数（best_k={best_k}），需≥2")
        return None

    # 检查数据是否包含必要列
    required_data_cols = ['孕妇代码', '孕周数值', 'Y染色体浓度']
    missing_data_cols = [col for col in required_data_cols if col not in data.columns]
    if missing_data_cols:
        print(f"错误：预处理数据缺少必要列：{missing_data_cols}")
        return None

    required_cluster_cols = ['孕妇代码', '聚类标签']
    missing_cluster_cols = [col for col in required_cluster_cols if col not in cluster_data.columns]
    if missing_cluster_cols:
        print(f"错误：聚类结果数据缺少必要列：{missing_cluster_cols}")
        return None

    # 风险函数（文档分级：12周内低风险，13-27中风险）
    def risk(week):
        if week <= 12:
            return 1  # 低风险
        elif 13 <= week <= 27:
            return 2  # 中风险
        else:
            return 3  # 高风险（超出常规检测范围）

    # 合并数据并处理缺失的聚类标签
    pregnant_cluster = cluster_data[['孕妇代码', '聚类标签']].copy()
    data_merged = data.merge(pregnant_cluster, on='孕妇代码', how='left')
    print(f"数据合并后总条数：{len(data_merged)}")

    # 过滤未匹配到聚类标签的数据
    missing_cluster_count = data_merged['聚类标签'].isnull().sum()
    if missing_cluster_count > 0:
        print(f"警告：{missing_cluster_count}条数据未匹配到聚类标签，已过滤")
        data_merged = data_merged.dropna(subset=['聚类标签'])
        data_merged['聚类标签'] = data_merged['聚类标签'].astype(int)

    # 检查合并后是否有有效数据
    if data_merged.empty:
        print("错误：过滤后无有效数据（所有数据未匹配到聚类标签）")
        return None
    print(f"过滤后有效数据条数：{len(data_merged)}")
    print(f"聚类标签分布：{data_merged['聚类标签'].value_counts().to_dict()}")

    # 按聚类组和孕周计算达标比例
    pregnant_data = []
    for cluster in range(best_k):
        # 提取当前聚类组数据
        cluster_subset = data_merged[data_merged['聚类标签'] == cluster].copy()
        print(f"\n聚类组{cluster}原始数据量：{len(cluster_subset)}")

        if cluster_subset.empty:
            print(f"警告：聚类组{cluster}无有效数据，跳过")
            continue

        # 按孕周分组计算达标比例（Y染色体浓度≥0.04为达标）
        week_groups = cluster_subset.groupby('孕周数值', as_index=False)
        compliance_stats = week_groups.agg(
            达标比例=('Y染色体浓度', lambda x: (x >= 0.04).mean())
        ).sort_values('孕周数值').reset_index(drop=True)

        print(f"聚类组{cluster}按孕周分组后的数据量：{len(compliance_stats)}（需≥5才能拟合）")
        compliance_stats['聚类标签'] = cluster
        pregnant_data.append(compliance_stats)

    # 检查是否有可用的分组统计数据
    if not pregnant_data:
        print("错误：所有聚类组均无有效分组数据，无法继续计算")
        return None

    # 合并所有聚类组的统计结果
    pregnant_data = pd.concat(pregnant_data, ignore_index=True)
    print(f"\n合并后所有聚类组的统计数据量：{len(pregnant_data)}")

    # 按聚类组进行多项式拟合（二次曲线）
    regression_params = {}
    for cluster in range(best_k):
        cluster_data = pregnant_data[pregnant_data['聚类标签'] == cluster]
        current_data_len = len(cluster_data)

        if current_data_len < 5:
            print(f"聚类组{cluster}样本量不足（{current_data_len} < 5），跳过拟合")
            continue

        # 提取x和y用于拟合
        x = cluster_data['孕周数值'].values
        y = cluster_data['达标比例'].values

        # 二次多项式拟合：y = a*t² + b*t + c
        try:
            a, b, c = np.polyfit(x, y, 2)
            regression_params[cluster] = (a, b, c)
            print(f"聚类组{cluster}拟合成功（a={a:.4f}, b={b:.4f}, c={c:.4f}）")
        except np.linalg.LinAlgError:
            print(f"聚类组{cluster}拟合失败（矩阵奇异，可能数据线性相关）")
            continue
        except Exception as e:
            print(f"聚类组{cluster}拟合时发生错误：{str(e)}")
            continue

    # 检查是否有成功拟合的聚类组
    if not regression_params:
        print("错误：所有聚类组拟合失败，无法计算最佳时点")
        return None
    print(f"\n成功拟合的聚类组：{list(regression_params.keys())}")

    # 计算每个聚类组的最佳时点
    optimal_timing = []
    for cluster, (a, b, c) in regression_params.items():
        # 遍历可能的孕周范围（10-25周，步长0.1）
        t_range = np.arange(10, 25.1, 0.1)

        # 约束达标比例在[0,1]范围内（避免拟合异常值）
        def get_valid_proportion(t):
            prop = a * t ** 2 + b * t + c
            return max(0.01, min(0.99, prop))  # 避免极端值影响目标函数

        # 目标函数：综合风险和达标比例（值越小越优）
        objective_values = [
            0.6 * risk(t) + 0.4 * (1 - get_valid_proportion(t))
            for t in t_range
        ]

        # 找到目标函数最小值对应的时点
        best_idx = np.argmin(objective_values)
        best_t = round(t_range[best_idx], 1)
        best_obj = round(objective_values[best_idx], 4)
        best_risk = risk(best_t)
        best_prop = round(get_valid_proportion(best_t), 4)

        optimal_timing.append({
            '聚类组': cluster,
            '最佳时点(周)': best_t,
            '目标函数值': best_obj,
            '该时点风险等级': best_risk,
            '该时点达标比例': best_prop
        })
        print(f"聚类组{cluster}最佳时点：{best_t}周（目标函数值：{best_obj}）")

    # 整理结果并保存为Excel格式
    result_df = pd.DataFrame(optimal_timing).sort_values('聚类组').reset_index(drop=True)
    output_path = os.path.join(OUTPUT_DIR, '6_最佳时点结果.xlsx')
    result_df.to_excel(output_path, index=False)
    print(f"\n最佳时点结果已保存至：{output_path}")

    # 绘制最佳时点对比图（确保有数据才绘图）
    if not result_df.empty:
        plt.figure(figsize=(12, 6))
        sns.barplot(
            x='聚类组',
            y='最佳时点(周)',
            data=result_df,
            palette='Blues_d',
            errorbar=None
        )
        plt.title('各聚类组最佳NIPT检测时点（孕周）')
        plt.xlabel('聚类组')
        plt.ylabel('最佳检测时点（周）')
        plt.ylim(7, 25)  # 限制Y轴范围，避免因数据波动导致的图像变形
        plt.grid(axis='y', linestyle='--', alpha=0.7)

        # 添加数据标签
        for i, row in enumerate(result_df.itertuples()):
            plt.text(i, row._2 + 0.2, f"{row._2}周", ha='center')

        plt.tight_layout()  # 自动调整布局，避免标签被截断
        plot_path = os.path.join(OUTPUT_DIR, '6_最佳时点对比.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')  # 确保标签完整保存
        plt.show()
        plt.close()
        print(f"最佳时点对比图已保存至：{plot_path}")
    else:
        print("警告：无有效结果数据，未生成对比图")

    print("第六部分结果：最佳时点计算完成")
    return result_df


# -------------------------- 主函数 --------------------------
if __name__ == "__main__":
    # 加载必要数据（从预处理和聚类结果文件中读取）
    try:
        # 1. 加载预处理后的数据（包含孕周、Y染色体浓度等）
        preprocessed_path = os.path.join(OUTPUT_DIR, '1_预处理后数据.xlsx')
        preprocessed_data = pd.read_excel(preprocessed_path)
        print(f"成功加载预处理数据（{len(preprocessed_data)}条）：{preprocessed_path}")

        # 2. 加载聚类结果数据（包含孕妇代码和聚类标签）
        cluster_result_path = os.path.join(OUTPUT_DIR, '4_聚类结果数据.xlsx')
        cluster_result = pd.read_excel(cluster_result_path)
        print(f"成功加载聚类结果（{len(cluster_result)}条）：{cluster_result_path}")

        # 3. 加载最佳聚类数（建议从聚类步骤的结果中自动读取，此处为示例）
        best_k = 2  # 需与实际聚类结果一致
        print(f"使用最佳聚类数：{best_k}")

    except FileNotFoundError as e:
        print(f"文件未找到错误：{e}")
        print("请确保预处理数据和聚类结果文件已生成并保存在results目录下")
        preprocessed_data = None
        cluster_result = None
        best_k = None
    except Exception as e:
        print(f"数据加载失败：{str(e)}")
        preprocessed_data = None
        cluster_result = None
        best_k = None

    # 调用最佳时点计算函数
    if preprocessed_data is not None and cluster_result is not None and best_k is not None:
        optimal_result = find_best_time(preprocessed_data, cluster_result, best_k)
    else:
        print("缺少必要输入数据，无法执行最佳时点计算")
