import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
import pickle
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, confusion_matrix, ConfusionMatrixDisplay,
                             roc_curve)  # 新增roc_curve导入
from imblearn.over_sampling import SMOTE
from DatasetDivide import prepare_data, read_selected_features, split_and_scale

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False


def train_models(X_train, y_train, selected_features):
    """优化过采样策略，调整模型参数"""
    models = {}
    for label in X_train.keys():
        if not selected_features[label]:
            continue

        # 打印正例分布
        pos_count = y_train[label].sum()
        pos_ratio = pos_count / len(y_train[label])
        print(f"\n{label}训练集: 总样本数={len(y_train[label])}, 正例数={pos_count}, 占比={pos_ratio:.2%}")

        # 过采样：控制采样比例
        if pos_ratio < 0.05:
            smote = SMOTE(sampling_strategy=0.2, random_state=42)
        elif pos_ratio < 0.1:
            smote = SMOTE(sampling_strategy=0.3, random_state=42)
        else:
            smote = SMOTE(sampling_strategy=0.5, random_state=42)

        X_resampled, y_resampled = smote.fit_resample(X_train[label], y_train[label])
        new_pos_ratio = y_resampled.sum() / len(y_resampled)
        print(f"过采样后：总样本数={len(X_resampled)}, 正例数={y_resampled.sum()}, 占比={new_pos_ratio:.2%}")

        # 模型参数（保持不变）
        lr = LogisticRegression(
            class_weight='balanced',
            random_state=42,
            max_iter=2000,
            C=0.05
        )
        svm = SVC(
            kernel='rbf',
            probability=True,
            class_weight='balanced',
            random_state=42,
            C=0.5,
            gamma='scale'
        )
        rf = RandomForestClassifier(
            n_estimators=150,
            class_weight='balanced_subsample',
            random_state=42,
            min_samples_leaf=3,
            max_depth=8,
            bootstrap=True
        )

        # 训练模型
        lr.fit(X_resampled, y_resampled)
        svm.fit(X_resampled, y_resampled)
        rf.fit(X_resampled, y_resampled)

        models[label] = {'lr': lr, 'svm': svm, 'rf': rf}
        print(f"{label}模型训练完成")

    return models


def get_thresholds(models, X_train, y_train, output_dir):
    """修正阈值计算，为SVM添加ROC曲线最佳阈值"""
    thresholds = {'lr': {}, 'svm': {}, 'rf': {}}

    for label in models.keys():
        # 逻辑回归阈值（保持不变）
        lr_probs = models[label]['lr'].predict_proba(X_train[label])[:, 1]
        pos_lr_probs = lr_probs[y_train[label] == 1]
        thresholds['lr'][label] = np.percentile(pos_lr_probs, 10) if len(pos_lr_probs) > 0 else 0.3

        # SVM：通过ROC曲线找到最佳阈值（与对角线距离最大的点）
        svm_probs = models[label]['svm'].predict_proba(X_train[label])[:, 1]
        y_true = y_train[label].values

        # 计算ROC曲线的FPR、TPR和阈值
        fpr, tpr, svm_thresholds = roc_curve(y_true, svm_probs)

        # 计算每个点到对角线的距离（最大化TPR - FPR）
        if len(fpr) > 0 and len(tpr) > 0:
            # 距离计算公式：TPR - FPR（越大表示距离对角线越远且性能越好）
            distances = tpr - fpr
            best_idx = np.argmax(distances)
            best_svm_threshold = svm_thresholds[best_idx]

            # 绘制并保存ROC曲线
            plt.figure(figsize=(8, 6))
            plt.plot(fpr, tpr, color='blue', label='SVM ROC曲线')
            plt.plot([0, 1], [0, 1], 'k--', label='随机猜测')  # 对角线
            plt.scatter(
                fpr[best_idx], tpr[best_idx],
                color='red', s=100, label=f'最佳阈值: {best_svm_threshold:.3f}'
            )
            plt.xlabel('假正例率 (FPR)')
            plt.ylabel('真正例率 (TPR)')
            plt.title(f'{label}的SVM ROC曲线与最佳阈值')
            plt.legend()
            plt.grid(alpha=0.3)
            plt.savefig(os.path.join(output_dir, f'4_{label}_SVM_ROC曲线.png'), dpi=300)
            plt.close()
        else:
            best_svm_threshold = 0.3  # 异常情况默认值

        thresholds['svm'][label] = best_svm_threshold

        # 随机森林阈值（保持不变）
        rf_probs = models[label]['rf'].predict_proba(X_train[label])[:, 1]
        pos_rf_probs = rf_probs[y_train[label] == 1]
        thresholds['rf'][label] = np.percentile(pos_rf_probs, 10) if len(pos_rf_probs) > 0 else 0.3

        # 打印阈值
        print(f"{label}阈值: lr={thresholds['lr'][label]:.3f}, svm={thresholds['svm'][label]:.3f}, "
              f"rf={thresholds['rf'][label]:.3f}")

    return thresholds


def evaluate_models(models, X_test, y_test, y, selected_features, output_dir, thresholds):
    """评估模型（保持原有逻辑）"""
    eval_results = {}
    for label in models.keys():
        if not selected_features[label]:
            continue

        test_indices = X_test[label].index
        y_true = y_test[label].values

        # 预测与概率计算
        y_pred = []
        probs = []
        for idx in test_indices:
            X_sample = X_test[label].loc[[idx]]

            # 各模型概率
            lr_prob = models[label]['lr'].predict_proba(X_sample)[0, 1]
            svm_prob = models[label]['svm'].predict_proba(X_sample)[0, 1]
            rf_prob = models[label]['rf'].predict_proba(X_sample)[0, 1]

            # 融合概率（保持SVM权重）
            prob = 0.2 * lr_prob + 0.5 * svm_prob + 0.3 * rf_prob
            probs.append(prob)

            # 融合阈值计算
            label_threshold = (thresholds['lr'][label] + thresholds['svm'][label] + thresholds['rf'][label]) / 3 * 0.8
            y_pred.append(1 if prob >= label_threshold else 0)

        # 计算指标
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, zero_division=0)
        recall = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)

        eval_results[label] = {
            '准确率': accuracy,
            '精确率': precision,
            '召回率': recall,
            'F1分数': f1
        }

        # 打印详细信息
        print(f"\n{label}测试集详细信息:")
        print(f"- 实际正例数: {sum(y_true)}, 预测正例数: {sum(y_pred)}")
        print(f"- 融合概率最大值: {max(probs):.3f}, 融合阈值: {label_threshold:.3f}")
        print(f"{label}评估结果: {eval_results[label]}")

        # 绘制混淆矩阵
        cm = confusion_matrix(y_true, y_pred)
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['正常', '异常'])
        disp.plot(cmap=plt.cm.Blues)
        plt.title(f'{label}的混淆矩阵')
        plt.savefig(os.path.join(output_dir, f'4_{label}_混淆矩阵.png'), dpi=300)
        plt.close()

    pd.DataFrame(eval_results).T.to_excel(os.path.join(output_dir, '4_模型评估结果.xlsx'))
    return eval_results


def main():
    X, y, label_cols, output_dir = prepare_data()
    selected_features = read_selected_features(os.path.join(output_dir, "2_筛选特征结果.xlsx"))
    X_train, X_test, y_train, y_test, scalers = split_and_scale(X, y, selected_features)

    models = train_models(X_train, y_train, selected_features)

    # 保存模型
    model_save_dir = os.path.join(output_dir, "trained_models")
    os.makedirs(model_save_dir, exist_ok=True)
    for label, model_dict in models.items():
        model_path = os.path.join(model_save_dir, f"{label}_model.pkl")
        with open(model_path, "wb") as f:
            pickle.dump(model_dict, f)
        print(f"模型 {label} 已保存至 {model_path}")

    thresholds = get_thresholds(models, X_train, y_train, output_dir)
    eval_results = evaluate_models(models, X_test, y_test, y, selected_features, output_dir, thresholds)
    print("\n模型评估完成，结果已保存至:", output_dir)


if __name__ == "__main__":
    main()