import pandas as pd
import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import kruskal
from sklearn.feature_selection import mutual_info_classif

plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams['axes.unicode_minus'] = False


def prepare_data(data_path="results/1_女胎预处理后数据.xlsx"):
    """读取数据并处理标签"""
    output_dir = "results"
    os.makedirs(output_dir, exist_ok=True)

    df = pd.read_excel(data_path)

    # 标签列定义（明确对应关系）
    label_cols = {
        'Y13': '13号染色体异常',
        'Y18': '18号染色体异常',
        'Y21': '21号染色体异常'
    }

    # 提取特征（排除标签列）
    features = df.drop(label_cols.keys(), axis=1).columns.tolist()
    X = df[features]
    y = df[label_cols.keys()]

    return X, y, label_cols, output_dir


def select_features(X, y_label, label_name, mi_percentile=30):
    """特征筛选逻辑（增加标签名称参数用于明确输出）"""
    # 非参数检验（Kruskal-Wallis）
    p_values = []
    for col in X.columns:
        groups = [X[col][y_label == cls] for cls in y_label.unique()]
        _, p = kruskal(*groups)
        p_values.append(p)
    p_values = np.array(p_values)
    kruskal_significant = p_values < 0.1

    # 互信息计算（动态阈值）
    mi_scores = mutual_info_classif(X, y_label)
    mi_threshold = np.percentile(mi_scores, 100 - mi_percentile)
    mi_significant = mi_scores >= mi_threshold

    # 筛选特征并返回
    selected_mask = kruskal_significant | mi_significant
    selected_feats = X.columns[selected_mask].tolist()
    # 明确标注当前筛选结果对应的染色体异常类型
    print(f"针对{label_name}筛选出{len(selected_feats)}个特征: {selected_feats}")
    return selected_feats


def save_results(results, output_dir, filename="2_筛选特征结果.xlsx"):
    """将筛选结果保存为Excel文件（修复数组长度不一致问题）"""
    # 提取所有特征列表并计算最大长度（关键修复点）
    all_feats = [feats for _, feats in results.values()]
    max_len = max(len(feats) for feats in all_feats)

    # 构建数据字典，确保每个列表长度一致
    data = {}
    for label, (label_desc, feats) in results.items():
        # 填充NaN使所有列表长度等于max_len
        padded_feats = feats + [np.nan] * (max_len - len(feats))
        data[label_desc] = padded_feats

    # 转换为DataFrame
    df_results = pd.DataFrame(data)

    # 保存文件
    save_path = os.path.join(output_dir, filename)
    df_results.to_excel(save_path, index=False)
    print(f"结果已保存至: {save_path}")


def main():
    # 数据准备（获取带描述的标签字典）
    X, y, label_cols, output_dir = prepare_data()

    # 特征筛选（记录每个标签对应的描述和特征）
    selected_features = {}
    for label, label_desc in label_cols.items():
        selected_feats = select_features(X, y[label], label_desc)
        selected_features[label] = (label_desc, selected_feats)

    # 保存结果
    save_results(selected_features, output_dir)


if __name__ == "__main__":
    main()
