import pandas as pd
import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from scipy import stats

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams['axes.unicode_minus'] = False


# ----------------------
# 1. 数据准备（分离孕妇代码）
# ----------------------
def prepare_data(data_path="results/1_女胎预处理后数据.xlsx"):
    """读取数据，分离孕妇代码、特征和标签"""
    output_dir = "results"
    os.makedirs(output_dir, exist_ok=True)

    if not os.path.exists(data_path):
        raise FileNotFoundError(f"数据文件不存在，请检查路径：{data_path}")

    df = pd.read_excel(data_path)

    # 检查孕妇代码列是否存在（对应文档中列B的孕妇代码）
    if '孕妇代码' not in df.columns:
        raise ValueError("数据中缺少'孕妇代码'列，请确保预处理数据包含该列")

    # 分离孕妇代码（作为标识列，不参与模型训练）
    pregnant_ids = df['孕妇代码'].copy()

    # 标签列定义
    label_cols = {
        'Y13': '13号染色体异常',
        'Y18': '18号染色体异常',
        'Y21': '21号染色体异常'
    }

    # 提取特征（排除标签列和孕妇代码）
    features = df.drop(list(label_cols.keys()) + ['孕妇代码'], axis=1).columns.tolist()
    X = df[features]
    y = df[label_cols.keys()]

    return X, y, pregnant_ids, label_cols, output_dir


# ----------------------
# 2. 从文件读取特征筛选结果
# ----------------------
def read_selected_features(feature_result_path):
    """从文件中读取特征筛选结果"""
    if not os.path.exists(feature_result_path):
        raise FileNotFoundError(f"特征筛选结果文件不存在，请检查路径：{feature_result_path}")

    df = pd.read_excel(feature_result_path)
    selected_features = {}
    for col in df.columns:
        feats = df[col].dropna().tolist()
        if '13' in col:
            selected_features['Y13'] = feats
        elif '18' in col:
            selected_features['Y18'] = feats
        elif '21' in col:
            selected_features['Y21'] = feats
    return selected_features


# ----------------------
# 3. 数据集划分与标准化（同步划分孕妇代码）
# ----------------------
def split_and_scale(X, y, pregnant_ids, selected_features):
    """划分特征、标签和孕妇代码，同时进行标准化"""
    X_train, X_test = {}, {}
    y_train, y_test = {}, {}
    ids_train, ids_test = {}, {}  # 存储各标签对应的孕妇代码
    scalers = {}

    for label in selected_features.keys():
        # 提取当前标签对应的特征
        X_label = X[selected_features[label]]

        # 分层抽样划分（同步划分特征、标签、孕妇代码）
        X_tr, X_te, y_tr, y_te, ids_tr, ids_te = train_test_split(
            X_label, y[label], pregnant_ids,
            test_size=0.3,
            random_state=42,
            stratify=y[label]  # 按标签分层，保证分布一致
        )

        # 标准化处理
        scaler = StandardScaler()
        X_tr_scaled = scaler.fit_transform(X_tr)
        X_te_scaled = scaler.transform(X_te)

        # 转换为DataFrame保留列名和索引
        X_train[label] = pd.DataFrame(
            X_tr_scaled,
            columns=X_tr.columns,
            index=X_tr.index
        )
        X_test[label] = pd.DataFrame(
            X_te_scaled,
            columns=X_te.columns,
            index=X_te.index
        )
        y_train[label] = y_tr
        y_test[label] = y_te
        ids_train[label] = ids_tr  # 保存训练集孕妇代码
        ids_test[label] = ids_te   # 保存测试集孕妇代码
        scalers[label] = scaler

    return X_train, X_test, y_train, y_test, ids_train, ids_test, scalers


# ----------------------
# 4. 保存划分结果（包含孕妇代码）
# ----------------------
def save_split_scaled_data(X_train, X_test, y_train, y_test, ids_train, ids_test, scalers, output_dir):
    """保存包含孕妇代码的训练集和测试集"""
    split_dir = os.path.join(output_dir, "split_scaled_data")
    os.makedirs(split_dir, exist_ok=True)

    for label in X_train.keys():
        # 训练集：拼接孕妇代码 + 特征
        train_data = pd.concat([
            ids_train[label].reset_index(drop=True),  # 重置索引确保对齐
            X_train[label].reset_index(drop=True)
        ], axis=1)
        # 测试集：拼接孕妇代码 + 特征
        test_data = pd.concat([
            ids_test[label].reset_index(drop=True),
            X_test[label].reset_index(drop=True)
        ], axis=1)

        # 保存特征数据（含孕妇代码）
        train_data.to_excel(os.path.join(split_dir, f"{label}_训练集特征.xlsx"), index=False)
        test_data.to_excel(os.path.join(split_dir, f"{label}_测试集特征.xlsx"), index=False)

        # 保存标签数据（含孕妇代码用于对应）
        train_label = pd.concat([
            ids_train[label].reset_index(drop=True),
            y_train[label].reset_index(drop=True)
        ], axis=1)
        test_label = pd.concat([
            ids_test[label].reset_index(drop=True),
            y_test[label].reset_index(drop=True)
        ], axis=1)
        train_label.to_excel(os.path.join(split_dir, f"{label}_训练集标签.xlsx"), index=False)
        test_label.to_excel(os.path.join(split_dir, f"{label}_测试集标签.xlsx"), index=False)

        # 保存标准化参数（不变）
        scaler_params = pd.DataFrame({
            "特征": X_train[label].columns,
            "均值": scalers[label].mean_,
            "标准差": scalers[label].scale_
        })
        scaler_params.to_excel(os.path.join(split_dir, f"{label}_标准化参数.xlsx"), index=False)

    print(f"含孕妇代码的数据集已保存至：{split_dir}")


# ----------------------
# 5. 特征关联可视化（保持不变）
# ----------------------
def plot_feature_correlation(X, y, label, features, output_dir):
    """绘制散点图和箱线图，判断特征与标签的关联类型"""
    if not features:
        return

    y_numeric = y.astype(int).values
    n_cols = 2
    n_rows = (len(features) + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols * 2, figsize=(16, 5 * n_rows))
    axes = axes.flatten()

    for i, feat in enumerate(features):
        X_feat = X[feat].values

        # 散点图
        ax_scatter = axes[i * 2]
        sns.regplot(
            x=X_feat,
            y=y_numeric,
            ax=ax_scatter,
            scatter_kws={'alpha': 0.5},
            line_kws={'color': 'red', 'lw': 2}
        )
        ax_scatter.set_title(f'{feat}与{label}的散点图（回归线）')
        ax_scatter.set_xlabel(feat)
        ax_scatter.set_ylabel(f'{label}（0=正常，1=异常）')
        ax_scatter.set_yticks([0, 1])

        # 箱线图
        ax_box = axes[i * 2 + 1]
        sns.boxplot(
            x=y,
            y=X_feat,
            ax=ax_box
        )
        pearson_r, _ = stats.pearsonr(X_feat, y_numeric)
        spearman_r, _ = stats.spearmanr(X_feat, y_numeric)
        ax_box.set_title(
            f'{feat}与{label}的箱线图\n'
            f'皮尔逊系数: {pearson_r:.3f} 斯皮尔曼系数: {spearman_r:.3f}'
        )
        ax_box.set_xlabel(f'{label}（0=正常，1=异常）')
        ax_box.set_ylabel(feat)

    # 隐藏未使用子图
    for i in range(len(features) * 2, len(axes)):
        axes[i].axis('off')

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'3_{label}_特征关联类型分析.png'), dpi=300)
    plt.close()


# ----------------------
# 主函数
# ----------------------
def main():
    # 1. 数据准备（含孕妇代码）
    X, y, pregnant_ids, label_cols, output_dir = prepare_data()
    print("数据准备完成，特征数量：", X.shape[1])
    print("标签列：", label_cols)
    print("孕妇代码数量：", len(pregnant_ids.unique()))  # 验证孕妇代码存在

    # 2. 读取特征筛选结果
    feature_result_path = os.path.join(output_dir, "2_筛选特征结果.xlsx")
    selected_features = read_selected_features(feature_result_path)
    for label, feats in selected_features.items():
        print(f"针对{label_cols[label]}的特征: {feats}")

    # 3. 划分与标准化（同步处理孕妇代码）
    X_train, X_test, y_train, y_test, ids_train, ids_test, scalers = split_and_scale(
        X, y, pregnant_ids, selected_features
    )
    print("数据集划分完成，训练集样本数：", {k: v.shape[0] for k, v in X_train.items()})

    # 4. 保存含孕妇代码的结果
    save_split_scaled_data(
        X_train, X_test, y_train, y_test, ids_train, ids_test, scalers, output_dir
    )

    # 5. 特征关联分析
    for label, label_desc in label_cols.items():
        if selected_features[label]:
            plot_feature_correlation(
                X_train[label],
                y_train[label],
                label_desc,
                selected_features[label],
                output_dir
            )
    print(f"特征关联分析图已保存至：{output_dir}")


if __name__ == "__main__":
    main()