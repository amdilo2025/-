import pandas as pd
import os

from matplotlib import pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import pickle
from sklearn.preprocessing import StandardScaler

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams['axes.unicode_minus'] = False


def load_test_data_and_assets(output_dir="results"):
    """加载测试数据、模型及真实标签"""
    # 1. 加载训练资产（模型、特征、标准化器）
    assets = {}
    # 加载特征筛选结果
    feat_path = os.path.join(output_dir, "2_筛选特征结果.xlsx")
    df_feats = pd.read_excel(feat_path)
    selected_features = {}
    for col in df_feats.columns:
        feats = df_feats[col].dropna().tolist()
        if '13' in col:
            selected_features['Y13'] = feats
        elif '18' in col:
            selected_features['Y18'] = feats
        elif '21' in col:
            selected_features['Y21'] = feats
    assets['selected_features'] = selected_features

    # 加载标准化器
    scalers = {}
    scaler_dir = os.path.join(output_dir, "split_scaled_data")
    for label in selected_features.keys():
        scaler_path = os.path.join(scaler_dir, f"{label}_标准化参数.xlsx")
        df_scaler = pd.read_excel(scaler_path)
        scaler = StandardScaler()
        scaler.mean_ = df_scaler['均值'].values
        scaler.scale_ = df_scaler['标准差'].values
        scaler.feature_names_in_ = df_scaler['特征'].values
        scalers[label] = scaler
    assets['scalers'] = scalers

    # 加载模型
    models = {}
    model_dir = os.path.join(output_dir, "trained_models")
    for label in selected_features.keys():
        with open(os.path.join(model_dir, f"{label}_model.pkl"), 'rb') as f:
            models[label] = pickle.load(f)
    assets['models'] = models

    # 2. 加载测试集特征和真实标签（含孕妇代码用于对齐）
    test_data = {}
    test_labels = {}
    for label in selected_features.keys():
        # 测试集特征（含孕妇代码）
        feat_path = os.path.join(scaler_dir, f"{label}_测试集特征.xlsx")
        test_data[label] = pd.read_excel(feat_path)
        # 测试集真实标签（含孕妇代码）
        label_path = os.path.join(scaler_dir, f"{label}_测试集标签.xlsx")
        test_labels[label] = pd.read_excel(label_path)

    return assets, test_data, test_labels


def predict_with_fusion(X_sample, model, sample_type):
    """融合模型预测概率"""
    lr_prob = model['lr'].predict_proba(X_sample)[:, 1]
    svm_prob = model['svm'].predict_proba(X_sample)[:, 1]
    rf_prob = model['rf'].predict_proba(X_sample)[:, 1]
    if sample_type == 'single':
        return 0.6 * rf_prob + 0.4 * svm_prob
    else:
        return 0.7 * svm_prob + 0.3 * rf_prob


def calculate_accuracy(assets, test_data, test_labels):
    """计算模型在测试集上的各项准确率指标"""
    selected_features = assets['selected_features']
    scalers = assets['scalers']
    models = assets['models']
    thresholds = {'Y13': 0.35, 'Y18': 0.30, 'Y21': 0.25}  # 与预测代码保持一致
    metrics = {}

    for label in selected_features.keys():
        # 1. 提取当前标签的测试数据（特征+孕妇代码）
        df_feat = test_data[label].copy()
        # 提取特征列（排除孕妇代码）
        feature_cols = [col for col in df_feat.columns if col != '孕妇代码']
        X_test = df_feat[feature_cols]

        # 2. 特征标准化
        X_scaled = scalers[label].transform(X_test[selected_features[label]])

        # 3. 预测概率并生成预测标签
        # 样本类型判断（与预测逻辑一致）
        temp_pred = []
        for l in selected_features.keys():
            if l != label:
                # 加载其他标签的测试特征用于类型判断
                l_feat = test_data[l][selected_features[l]]
                l_scaled = scalers[l].transform(l_feat)
                prob = predict_with_fusion(l_scaled, models[l], 'single')
                temp_pred.append((prob >= 0.4).astype(int))
        cnt = sum(temp_pred)
        sample_type = ['single' if c <= 1 else 'combined' for c in cnt]

        # 融合预测概率
        pred_probs = []
        for i in range(len(sample_type)):
            if sample_type[i] == 'single':
                prob = 0.6 * models[label]['rf'].predict_proba(X_scaled[i:i + 1])[0, 1] + \
                       0.4 * models[label]['svm'].predict_proba(X_scaled[i:i + 1])[0, 1]
            else:
                prob = 0.7 * models[label]['svm'].predict_proba(X_scaled[i:i + 1])[0, 1] + \
                       0.3 * models[label]['rf'].predict_proba(X_scaled[i:i + 1])[0, 1]
            pred_probs.append(prob)
        y_pred = [1 if p >= thresholds[label] else 0 for p in pred_probs]

        # 4. 获取真实标签（通过孕妇代码对齐，确保样本匹配）
        # 测试集标签包含孕妇代码和真实标签（label列）
        df_true = test_labels[label].copy()
        # 按孕妇代码对齐预测结果与真实标签
        pred_df = pd.DataFrame({
            '孕妇代码': df_feat['孕妇代码'],
            'y_pred': y_pred
        })
        merged = pd.merge(pred_df, df_true, on='孕妇代码', how='inner')
        y_true = merged[label].values
        y_pred_aligned = merged['y_pred'].values

        # 5. 计算评估指标（参考文档中染色体非整倍体判定需求）
        metrics[label] = {
            '准确率(Accuracy)': accuracy_score(y_true, y_pred_aligned),
        }

    return metrics


def save_accuracy_results(metrics, output_dir="results"):
    """保存准确率结果到Excel"""
    # 转换为DataFrame
    result_df = pd.DataFrame(metrics).T  # 转置使标签为行，指标为列
    # 保存文件
    output_path = os.path.join(output_dir, "6_模型准确率评估结果.xlsx")
    result_df.to_excel(output_path)
    print(f"模型准确率评估结果已保存至：{output_path}")
    # 打印关键指标
    print("\n模型准确率 summary：")
    print(result_df['准确率(Accuracy)'].round(4))


def main():
    # 加载测试数据和模型资产
    assets, test_data, test_labels = load_test_data_and_assets()
    # 计算准确率指标
    metrics = calculate_accuracy(assets, test_data, test_labels)
    # 保存并输出结果
    save_accuracy_results(metrics)


if __name__ == "__main__":
    main()