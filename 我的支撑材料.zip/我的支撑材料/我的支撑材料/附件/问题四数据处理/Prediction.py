import pandas as pd
import pickle
import os

from matplotlib import pyplot as plt
from sklearn.preprocessing import StandardScaler

# 设置中文显示
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams['axes.unicode_minus'] = False


def load_training_assets(output_dir="results"):
    """加载训练过程中保存的关键组件"""
    assets = {}

    # 1. 加载特征筛选结果
    feat_path = os.path.join(output_dir, "2_筛选特征结果.xlsx")
    df_feats = pd.read_excel(feat_path)
    selected_features = {}
    for col in df_feats.columns:
        feats = df_feats[col].dropna().tolist()
        if '13' in col:
            selected_features['Y13'] = feats
        elif '18' in col:
            selected_features['Y18'] = feats
        elif '21' in col:
            selected_features['Y21'] = feats
    assets['selected_features'] = selected_features

    # 2. 加载标准化器
    scalers = {}
    scaler_dir = os.path.join(output_dir, "split_scaled_data")
    for label in selected_features.keys():
        scaler_path = os.path.join(scaler_dir, f"{label}_标准化参数.xlsx")
        df_scaler = pd.read_excel(scaler_path)
        scaler = StandardScaler()
        scaler.mean_ = df_scaler['均值'].values
        scaler.scale_ = df_scaler['标准差'].values
        scaler.feature_names_in_ = df_scaler['特征'].values
        scalers[label] = scaler
    assets['scalers'] = scalers

    # 3. 加载训练好的模型
    models = {}
    model_dir = os.path.join(output_dir, "trained_models")
    for label in selected_features.keys():
        with open(os.path.join(model_dir, f"{label}_model.pkl"), 'rb') as f:
            models[label] = pickle.load(f)
    assets['models'] = models

    # 4. 加载模型评估结果
    eval_path = os.path.join(output_dir, "4_模型评估结果.xlsx")
    assets['eval_results'] = pd.read_excel(eval_path)

    return assets


def predict_with_fusion(X_sample, model, label, sample_type):
    """融合模型预测所有样本的概率"""
    lr_prob = model['lr'].predict_proba(X_sample)[:, 1]
    svm_prob = model['svm'].predict_proba(X_sample)[:, 1]
    rf_prob = model['rf'].predict_proba(X_sample)[:, 1]

    if sample_type == 'single':
        return 0.6 * rf_prob + 0.4 * svm_prob
    else:
        return 0.7 * svm_prob + 0.3 * rf_prob


def predict_female_fetus(new_data, assets):
    """预测所有样本的女胎异常情况"""
    selected_features = assets['selected_features']
    scalers = assets['scalers']
    models = assets['models']

    # 1. 特征预处理与标准化（排除孕妇代码，仅用特征列）
    feature_cols = [col for col in new_data.columns if col != '孕妇代码']
    processed = {}
    for label in selected_features.keys():
        required_feats = selected_features[label]
        missing = [f for f in required_feats if f not in feature_cols]
        if missing:
            raise ValueError(f"新样本缺少特征：{missing}（{label}模型所需）")

        X_new = new_data[required_feats].copy()
        X_scaled = scalers[label].transform(X_new)
        processed[label] = pd.DataFrame(X_scaled, columns=required_feats)

    # 2. 预测每个染色体的所有样本
    pred_probs = {}
    for label in selected_features.keys():
        temp_pred = []
        for l in selected_features.keys():
            if l != label:
                prob = predict_with_fusion(processed[l], models[l], l, 'single')
                temp_pred.append((prob >= 0.4).astype(int))
        cnt = sum(temp_pred)
        sample_type = ['single' if c <= 1 else 'combined' for c in cnt]

        all_probs = []
        for i in range(len(sample_type)):
            if sample_type[i] == 'single':
                prob = 0.6 * models[label]['rf'].predict_proba(processed[label].iloc[[i]])[0, 1] + \
                       0.4 * models[label]['svm'].predict_proba(processed[label].iloc[[i]])[0, 1]
            else:
                prob = 0.7 * models[label]['svm'].predict_proba(processed[label].iloc[[i]])[0, 1] + \
                       0.3 * models[label]['rf'].predict_proba(processed[label].iloc[[i]])[0, 1]
            all_probs.append(prob)
        pred_probs[label] = all_probs

    # 3. 动态阈值判断
    thresholds = {
        'Y13': 0.35,
        'Y18': 0.30,
        'Y21': 0.25
    }

    # 4. 批量结果判定
    results = []
    for i in range(len(new_data)):
        type = []
        for label in selected_features.keys():
            if pred_probs[label][i] >= thresholds[label]:
                type.append(f"{label[1:]}号染色体")
        if type:
            results.append(f"女胎异常，可能存在 {', '.join(type)} 非整倍体")
        else:
            results.append("女胎正常")
    return results


def main():
    assets = load_training_assets()

    # 读取测试集特征数据（含孕妇代码）
    df_Y13 = pd.read_excel('results/split_scaled_data/Y13_测试集特征.xlsx')
    df_Y18 = pd.read_excel('results/split_scaled_data/Y18_测试集特征.xlsx')
    df_Y21 = pd.read_excel('results/split_scaled_data/Y21_测试集特征.xlsx')

    # 合并数据（保留孕妇代码，去重列）
    new_sample = pd.concat([df_Y13, df_Y18, df_Y21], axis=1)
    new_sample = new_sample.loc[:, ~new_sample.columns.duplicated()]

    # 检查孕妇代码列是否存在
    if '孕妇代码' not in new_sample.columns:
        raise ValueError("测试集特征数据中缺少'孕妇代码'列，请确保数据包含该列")

    # 提取孕妇代码列表
    pregnant_ids = new_sample['孕妇代码'].tolist()

    # 批量预测
    pred_results = predict_female_fetus(new_sample, assets)

    # 保存结果到Excel
    result_df = pd.DataFrame({
        '孕妇代码': pregnant_ids,
        '预测结果': pred_results
    })
    output_path = os.path.join("results", "5_女胎异常预测结果.xlsx")
    result_df.to_excel(output_path, index=False)
    print(f"预测结果已保存至：{output_path}")


if __name__ == "__main__":
    main()