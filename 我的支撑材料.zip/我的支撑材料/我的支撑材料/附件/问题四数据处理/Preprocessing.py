import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import os

# 确保输出目录存在
output_dir = "results"
os.makedirs(output_dir, exist_ok=True)

# ----------------------
# 1. 数据读取与筛选（女胎样本）
# ----------------------
# 读取文件
excel_file = pd.ExcelFile('C题数据.xlsx')

# 获取对应工作表中数据
df_female = excel_file.parse('女胎检测数据')


# 查看数据集行数和列数
rows, columns = df_female.shape

if rows < 100 and columns < 20:
    # 短表数据（行数少于100且列数少于20）查看全量数据信息
    print('df_female全部内容信息：')
    print(df_female.to_csv(sep='\t', na_rep='nan'))

# ----------------------
# 2. 数据预处理
# ----------------------
# 2.1 处理孕周：将字符串（如'11w+6'）转换为数值（单位：周）
def convert_gestational_week(week_str):
    if pd.isna(week_str):
        return np.nan
    week_str = str(week_str).lower().replace(' ', '')
    if 'w' in week_str:
        parts = week_str.split('w')
        weeks = float(parts[0])
        days = 0.0
        if '+' in parts[1]:
            days = float(parts[1].split('+')[1])
        return weeks + days / 7  # 天数转换为周
    return float(week_str)


df_female['孕周数值'] = df_female['检测孕周'].apply(convert_gestational_week)

# 2.2 清洗GC含量异常样本（保留13、18、21号染色体GC含量在40%~60%的样本）
gc_cols = [
    'GC含量'
]
# 筛选GC含量在[0.4, 0.6]范围内的样本
mask_gc = (df_female[gc_cols] >= 0.4).all(axis=1) & (df_female[gc_cols] <= 0.6).all(axis=1)
df_female = df_female[mask_gc].dropna(subset=gc_cols + ['孕周数值', '孕妇BMI', '年龄'])


# ----------------------
# 3. 生成标签（AB列拆解为Y13、Y18、Y21）
# ----------------------
def process_ab(ab_value):
    """将AB列的非整倍体结果拆解为三个二元标签"""
    y13, y18, y21 = 0, 0, 0
    if pd.isna(ab_value):
        return (y13, y18, y21)
    ab_str = str(ab_value).upper()
    if 'T13' in ab_str:
        y13 = 1
    if 'T18' in ab_str:
        y18 = 1
    if 'T21' in ab_str:
        y21 = 1
    return (y13, y18, y21)


# 应用函数生成标签
ab_labels = df_female['染色体的非整倍体'].apply(lambda x: pd.Series(process_ab(x), index=['Y13', 'Y18', 'Y21']))
df_female = pd.concat([df_female, ab_labels], axis=1)  # 用concat确保列数匹配

# ----------------------
# 4. 特征工程
# ----------------------
# 4.1 染色体Z值特征（直接保留）
z_features = df_female[
    ['13号染色体的Z值',
     '18号染色体的Z值',
     '21号染色体的Z值',
     'X染色体的Z值']
].copy()
z_features.columns = ['Z13', 'Z18', 'Z21', 'ZX']  # 重命名列名

# 4.2 GC含量中点偏差（量化偏离正常范围的程度）
gc_deviation = pd.DataFrame()
for col, name in zip(gc_cols, ['GC13', 'GC18', 'GC21']):
    # 正常范围中点为50%，计算（实际值-50%）/10%（标准化偏差）
    gc_deviation[f'{name}_偏差'] = (df_female[col] - 0.5) / 0.1

# 4.3 读段数相关比例特征
read_features = pd.DataFrame()
# 确保列名完全匹配
read_features['唯一比对的读段占比'] = df_female['唯一比对的读段数'] / df_female['原始读段数']  # 注意列名
read_features['重复读段比例'] = df_female['重复读段的比例']
read_features['比对比例'] = df_female['在参考基因组上比对的比例']

# 4.4 孕妇特征标准化（年龄、孕周、BMI）
scaler = StandardScaler()
maternal_features = df_female[['年龄', '孕周数值', '孕妇BMI']].copy()
maternal_scaled = pd.DataFrame(
    scaler.fit_transform(maternal_features),
    columns=['年龄_标准化', '孕周_标准化', 'BMI_标准化'],
    index=maternal_features.index
)

# ----------------------
# 5. 合并特征、标签与孕妇代码，输出最终数据集
# ----------------------
# 提取孕妇代码（假设列名为“孕妇代码”，对应文档中列B）
pregnant_id = df_female[['孕妇代码']].copy()

# 合并所有内容（包含孕妇代码）
final_features = pd.concat([pregnant_id, z_features, gc_deviation, read_features, maternal_scaled], axis=1)
final_df = pd.concat([final_features, df_female[['Y13', 'Y18', 'Y21']]], axis=1)

# 打印数据集信息
print(f"处理后女胎样本量：{final_df.shape[0]}")
print("特征列：", final_df.columns.tolist())

# 数据验证
required_columns = [
    '孕妇代码',  # 新增验证孕妇代码列
    '唯一比对的读段数', '原始读段数', '重复读段的比例',
    '在参考基因组上比对的比例', '年龄', '孕周数值', '孕妇BMI'
]

missing_columns = [col for col in required_columns if col not in df_female.columns]
if missing_columns:
    raise ValueError(f"缺少必要的列: {missing_columns}")

# 检查是否存在空值
null_columns = df_female[required_columns].columns[df_female[required_columns].isnull().any()].tolist()
if null_columns:
    print(f"警告：以下列存在空值: {null_columns}")

# 保存最终预处理后的数据
if not final_df.empty:
    # 检查是否存在无穷值
    if final_df.isin([np.inf, -np.inf]).any().any():
        print("警告：数据中存在无穷值，已替换为NaN")
        final_df = final_df.replace([np.inf, -np.inf], np.nan)

    # 保存包含孕妇代码的文件
    output_path = os.path.join(output_dir, '1_女胎预处理后数据.xlsx')
    final_df.to_excel(output_path, index=False)
    print(f"预处理后的数据已保存至: {output_path}")
else:
    print("警告：处理后的数据集为空，未保存文件")